package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class chem extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(chem.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the chemical symbol for water?", new String[]{"H2O", "O2", "CO2", "H2O2"}, 0));
        questions.add(new Question("What is the atomic number of carbon?", new String[]{"6", "12", "8", "14"}, 0));
        questions.add(new Question("Which element is represented by the symbol 'Na'?", new String[]{"Sodium", "Nickel", "Nitrogen", "Neon"}, 0));
        questions.add(new Question("What is the chemical formula for methane?", new String[]{"CH4", "C2H6", "C3H8", "CO2"}, 0));
        questions.add(new Question("Which gas is most abundant in the Earth's atmosphere?", new String[]{"Oxygen", "Hydrogen", "Nitrogen", "Carbon dioxide"}, 2));
        questions.add(new Question("What is the main component of natural gas?", new String[]{"Methane", "Ethane", "Propane", "Butane"}, 0));
        questions.add(new Question("What is the pH of pure water?", new String[]{"7", "0", "14", "4"}, 0));
        questions.add(new Question("Which element has the atomic number 8?", new String[]{"Oxygen", "Nitrogen", "Carbon", "Hydrogen"}, 0));
        questions.add(new Question("What is the common name for dihydrogen monoxide?", new String[]{"Water", "Hydrogen peroxide", "Ammonia", "Hydrogen chloride"}, 0));
        questions.add(new Question("What is the chemical formula for carbon dioxide?", new String[]{"CO2", "CO", "C2O", "C3O2"}, 0));
        questions.add(new Question("Which of these is an alkali metal?", new String[]{"Sodium", "Magnesium", "Calcium", "Iron"}, 0));
        questions.add(new Question("What is the atomic number of gold?", new String[]{"79", "80", "78", "76"}, 0));
        questions.add(new Question("What is the most abundant element in the universe?", new String[]{"Oxygen", "Hydrogen", "Carbon", "Nitrogen"}, 1));
        questions.add(new Question("What is the chemical symbol for helium?", new String[]{"He", "H", "Li", "Ho"}, 0));
        questions.add(new Question("Which of these elements is a noble gas?", new String[]{"Neon", "Oxygen", "Nitrogen", "Carbon"}, 0));
        questions.add(new Question("What type of bond involves the sharing of electron pairs?", new String[]{"Covalent", "Ionic", "Metallic", "Hydrogen"}, 0));
        questions.add(new Question("What is the formula for sulfuric acid?", new String[]{"H2SO4", "HCl", "HNO3", "H2CO3"}, 0));
        questions.add(new Question("Which of the following is a halogen?", new String[]{"Fluorine", "Neon", "Oxygen", "Carbon"}, 0));
        questions.add(new Question("What is the symbol for the element potassium?", new String[]{"K", "P", "Pt", "Pu"}, 0));
        questions.add(new Question("Which of the following is an example of an exothermic reaction?", new String[]{"Burning wood", "Melting ice", "Dissolving salt in water", "Evaporating water"}, 0));
        questions.add(new Question("What is the chemical formula for ammonia?", new String[]{"NH3", "NH4", "N2H2", "N2O"}, 0));
        questions.add(new Question("Which type of chemical bond involves the transfer of electrons?", new String[]{"Ionic", "Covalent", "Hydrogen", "Van der Waals"}, 0));
        questions.add(new Question("Which of the following is a common acid?", new String[]{"Hydrochloric acid", "Sodium chloride", "Ammonia", "Magnesium sulfate"}, 0));
        questions.add(new Question("What is the most reactive group of metals in the periodic table?", new String[]{"Noble gases", "Alkaline earth metals", "Alkali metals", "Transition metals"}, 2));
        questions.add(new Question("What is the molecular formula for glucose?", new String[]{"C6H12O6", "C6H10O5", "C5H10O5", "C7H14O7"}, 0));
        questions.add(new Question("Which of the following is an example of a chemical change?", new String[]{"Burning paper", "Dissolving salt in water", "Melting ice", "Boiling water"}, 0));
        questions.add(new Question("Which element is represented by the symbol 'Fe'?", new String[]{"Iron", "Fluorine", "Francium", "Fermium"}, 0));
        questions.add(new Question("What is the main type of bond in sodium chloride (NaCl)?", new String[]{"Ionic", "Covalent", "Metallic", "Hydrogen"}, 0));
        questions.add(new Question("Which of the following compounds is a base?", new String[]{"NaOH", "HCl", "H2SO4", "CO2"}, 0));
        questions.add(new Question("What is the chemical formula for hydrochloric acid?", new String[]{"HCl", "H2SO4", "HNO3", "H2CO3"}, 0));
        questions.add(new Question("Which of the following is a product of photosynthesis?", new String[]{"Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"}, 0));
        questions.add(new Question("What is the atomic number of hydrogen?", new String[]{"1", "2", "3", "4"}, 0));
        questions.add(new Question("Which of the following elements is a metalloid?", new String[]{"Silicon", "Sodium", "Calcium", "Chlorine"}, 0));
        questions.add(new Question("What is the chemical symbol for silver?", new String[]{"Ag", "Si", "Sl", "Sg"}, 0));
        questions.add(new Question("What is the most abundant element in the Earth's crust?", new String[]{"Oxygen", "Silicon", "Aluminum", "Iron"}, 0));
        questions.add(new Question("What is the chemical formula for ozone?", new String[]{"O3", "O2", "O4", "O6"}, 0));
        questions.add(new Question("What is the process called when a liquid turns into gas?", new String[]{"Boiling", "Freezing", "Condensation", "Sublimation"}, 0));
        questions.add(new Question("What is the chemical formula for calcium carbonate?", new String[]{"CaCO3", "CaSO4", "CaCl2", "CaO"}, 0));
        questions.add(new Question("What is the color of litmus paper in a basic solution?", new String[]{"Red", "Blue", "Purple", "Green"}, 1));
        questions.add(new Question("Which type of radiation has the shortest wavelength?", new String[]{"Gamma rays", "Ultraviolet", "Visible light", "Radio waves"}, 0));
        questions.add(new Question("Which of the following is a strong acid?", new String[]{"Hydrochloric acid", "Acetic acid", "Carbonic acid", "Citric acid"}, 0));
        questions.add(new Question("What is the symbol for the element calcium?", new String[]{"Ca", "C", "Cl", "Cu"}, 0));
        questions.add(new Question("What is the chemical formula for hydrogen peroxide?", new String[]{"H2O2", "H2O", "H2O3", "H2SO4"}, 0));
        questions.add(new Question("Which of these gases is used in balloons?", new String[]{"Helium", "Oxygen", "Carbon dioxide", "Hydrogen"}, 0));
        questions.add(new Question("Which of these compounds is an example of a covalent bond?", new String[]{"Water (H2O)", "Sodium chloride (NaCl)", "Magnesium oxide (MgO)", "Calcium fluoride (CaF2)"}, 0));
        questions.add(new Question("Which of these is a noble gas?", new String[]{"Argon", "Oxygen", "Nitrogen", "Carbon"}, 0));
        questions.add(new Question("What is the atomic number of helium?", new String[]{"2", "1", "3", "4"}, 0));
        questions.add(new Question("What is the chemical symbol for the element mercury?", new String[]{"Hg", "He", "Mn", "Mo"}, 0));
        questions.add(new Question("What is the process of turning a solid directly into a gas called?", new String[]{"Sublimation", "Melting", "Evaporation", "Condensation"}, 0));
        questions.add(new Question("What is the chemical formula for methane?", new String[]{"CH4", "C2H6", "C3H8", "CO2"}, 0));
        questions.add(new Question("What type of bond is formed when two atoms share electrons?", new String[]{"Covalent", "Ionic", "Hydrogen", "Van der Waals"}, 0));
        questions.add(new Question("Which of the following is an example of a chemical reaction?", new String[]{"Rusting iron", "Melting ice", "Dissolving sugar in water", "Boiling water"}, 0));
        questions.add(new Question("Which of the following is a diatomic molecule?", new String[]{"O2", "N2", "H2", "All of the above"}, 3));
        questions.add(new Question("What is the common name for NaCl?", new String[]{"Salt", "Sugar", "Baking soda", "Lime"}, 0));
        questions.add(new Question("What is the most reactive element in Group 1 of the periodic table?", new String[]{"Sodium", "Lithium", "Potassium", "Rubidium"}, 2));
        questions.add(new Question("What is the process called when a liquid turns into a solid?", new String[]{"Freezing", "Boiling", "Condensation", "Sublimation"}, 0));
        questions.add(new Question("Which of the following is an example of a physical change?", new String[]{"Melting ice", "Rusting of iron", "Burning wood", "Digesting food"}, 0));
        questions.add(new Question("What is the term for a substance that speeds up a chemical reaction?", new String[]{"Catalyst", "Reactant", "Solvent", "Product"}, 0));
        questions.add(new Question("Which element is the main component of organic molecules?", new String[]{"Carbon", "Hydrogen", "Oxygen", "Nitrogen"}, 0));
        questions.add(new Question("What is the molar mass of carbon dioxide (CO2)?", new String[]{"44 g/mol", "32 g/mol", "28 g/mol", "18 g/mol"}, 0));
        questions.add(new Question("What is the number of protons in an atom of oxygen?", new String[]{"8", "6", "10", "12"}, 0));
        questions.add(new Question("What is the boiling point of water in Celsius?", new String[]{"100°C", "0°C", "50°C", "212°C"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
