package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class questions extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(questions.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the smallest country in the world?", new String[]{"Monaco", "Vatican City", "San Marino", "Liechtenstein"}, 1));
        questions.add(new Question("What is the capital of France?", new String[]{"Berlin", "Madrid", "Paris", "Rome"}, 2));
        questions.add(new Question("Which planet is known as the Red Planet?", new String[]{"Venus", "Mars", "Jupiter", "Saturn"}, 1));
        questions.add(new Question("Who wrote 'Romeo and Juliet'?", new String[]{"Shakespeare", "Dickens", "Austen", "Hemingway"}, 0));
        questions.add(new Question("What is the largest ocean on Earth?", new String[]{"Atlantic", "Indian", "Arctic", "Pacific"}, 3));
        questions.add(new Question("Who painted the Mona Lisa?", new String[]{"Van Gogh", "Da Vinci", "Picasso", "Rembrandt"}, 1));
        questions.add(new Question("What is the tallest mountain on Earth?", new String[]{"K2", "Kangchenjunga", "Mount Everest", "Makalu"}, 2));
        questions.add(new Question("Who invented the telephone?", new String[]{"Bell", "Edison", "Tesla", "Faraday"}, 0));
        questions.add(new Question("What is the main ingredient in guacamole?", new String[]{"Tomato", "Avocado", "Onion", "Lemon"}, 1));
        questions.add(new Question("In what year did the Titanic sink?", new String[]{"1912", "1920", "1898", "1935"}, 0));
        questions.add(new Question("What is the longest river in the world?", new String[]{"Amazon", "Nile", "Yangtze", "Mississippi"}, 1));
        questions.add(new Question("What is the currency of Japan?", new String[]{"Yuan", "Yen", "Ringgit", "Won"}, 1));
        questions.add(new Question("Which country is famous for the Great Wall?", new String[]{"India", "China", "Japan", "Korea"}, 1));
        questions.add(new Question("What is the capital of Canada?", new String[]{"Toronto", "Ottawa", "Vancouver", "Montreal"}, 1));
        questions.add(new Question("Who discovered gravity?", new String[]{"Albert Einstein", "Isaac Newton", "Galileo Galilei", "Nikola Tesla"}, 1));
        questions.add(new Question("What is the chemical symbol for gold?", new String[]{"Au", "Ag", "Pb", "Fe"}, 0));
        questions.add(new Question("Which planet is closest to the Sun?", new String[]{"Venus", "Mercury", "Earth", "Mars"}, 1));
        questions.add(new Question("What is the largest mammal?", new String[]{"Elephant", "Blue Whale", "Giraffe", "Hippopotamus"}, 1));
        questions.add(new Question("Who wrote '1984'?", new String[]{"Aldous Huxley", "George Orwell", "Ray Bradbury", "J.D. Salinger"}, 1));
        questions.add(new Question("What is the hardest naturally occurring mineral?", new String[]{"Diamond", "Quartz", "Topaz", "Ruby"}, 0));
        questions.add(new Question("Which gas is most abundant in Earth's atmosphere?", new String[]{"Oxygen", "Nitrogen", "Carbon Dioxide", "Argon"}, 1));
        questions.add(new Question("What is the capital of Brazil?", new String[]{"Rio de Janeiro", "Brasília", "São Paulo", "Salvador"}, 1));
        questions.add(new Question("What is the capital of Japan?", new String[]{"Beijing", "Seoul", "Tokyo", "Hong Kong"}, 2));
        questions.add(new Question("Who developed the theory of relativity?", new String[]{"Isaac Newton", "Nikola Tesla", "Albert Einstein", "Marie Curie"}, 2));
        questions.add(new Question("What is the fastest land animal?", new String[]{"Cheetah", "Lion", "Elephant", "Horse"}, 0));
        questions.add(new Question("Who discovered America?", new String[]{"Christopher Columbus", "Marco Polo", "Vasco da Gama", "Ferdinand Magellan"}, 0));
        questions.add(new Question("What is the chemical symbol for water?", new String[]{"O2", "H2O", "CO2", "NaCl"}, 1));
        questions.add(new Question("Which element has the atomic number 1?", new String[]{"Oxygen", "Hydrogen", "Carbon", "Nitrogen"}, 1));
        questions.add(new Question("Which country is known as the Land of the Rising Sun?", new String[]{"China", "Japan", "South Korea", "Thailand"}, 1));
        questions.add(new Question("What is the square root of 64?", new String[]{"6", "7", "8", "9"}, 2));
        questions.add(new Question("Which planet has the most moons?", new String[]{"Earth", "Mars", "Jupiter", "Saturn"}, 3));
        questions.add(new Question("Who discovered penicillin?", new String[]{"Marie Curie", "Alexander Fleming", "Louis Pasteur", "Joseph Lister"}, 1));
        questions.add(new Question("Which continent is the largest by land area?", new String[]{"North America", "Europe", "Asia", "Africa"}, 2));
        questions.add(new Question("Which animal is known as the King of the Jungle?", new String[]{"Tiger", "Elephant", "Lion", "Cheetah"}, 2));
        questions.add(new Question("What is the hardest natural substance on Earth?", new String[]{"Gold", "Iron", "Diamond", "Platinum"}, 2));
        questions.add(new Question("How many continents are there on Earth?", new String[]{"5", "6", "7", "8"}, 2));
        questions.add(new Question("Which organ is responsible for pumping blood throughout the body?", new String[]{"Lungs", "Brain", "Heart", "Liver"}, 2));
        questions.add(new Question("What is the capital of Australia?", new String[]{"Sydney", "Melbourne", "Canberra", "Perth"}, 2));
        questions.add(new Question("Which planet is the hottest in the solar system?", new String[]{"Mercury", "Venus", "Mars", "Jupiter"}, 1));
        questions.add(new Question("What is the name of the largest bone in the human body?", new String[]{"Femur", "Tibia", "Humerus", "Fibula"}, 0));
        questions.add(new Question("Which metal is liquid at room temperature?", new String[]{"Mercury", "Iron", "Gold", "Silver"}, 0));
        questions.add(new Question("Which gas do plants absorb from the atmosphere?", new String[]{"Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"}, 1));
        questions.add(new Question("How many sides does a hexagon have?", new String[]{"4", "5", "6", "7"}, 2));
        questions.add(new Question("How many bones are in the adult human body?", new String[]{"200", "206", "210", "180"}, 1));
        questions.add(new Question("What is the capital of the United Kingdom?", new String[]{"Paris", "London", "Berlin", "Madrid"}, 1));
        questions.add(new Question("Who was the first emperor of China?", new String[]{"Qin Shi Huang", "Emperor Wu", "Tang Taizong", "Li Shimin"}, 0));
        questions.add(new Question("Which element is most abundant in the human body?", new String[]{"Oxygen", "Carbon", "Hydrogen", "Nitrogen"}, 0));
        questions.add(new Question("What is the study of heredity and variation in organisms called?", new String[]{"Anatomy", "Genetics", "Biochemistry", "Physiology"}, 1));
        questions.add(new Question("Which religious text is central to Hinduism?", new String[]{"Torah", "Bible", "Vedas", "Quran"}, 2));
        questions.add(new Question("What is the largest planet in the solar system?", new String[]{"Earth", "Mars", "Jupiter", "Saturn"}, 2));
        questions.add(new Question("Which mammal can fly?", new String[]{"Bat", "Flying Squirrel", "Eagle", "Hawk"}, 0));
        questions.add(new Question("Which language has the most native speakers worldwide?", new String[]{"English", "Mandarin Chinese", "Spanish", "Hindi"}, 1));
        questions.add(new Question("How many hearts does an octopus have?", new String[]{"1", "2", "3", "4"}, 2));
        // ... (Add more questions here)questions.add(new Question("Which element is most abundant in the human body?", new String[]{"Oxygen", "Carbon", "Hydrogen", "Nitrogen"}, 0));
    }

    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
