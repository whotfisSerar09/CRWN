package com.data.crowner;  // Replace with your package

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class principal extends AppCompatActivity {

    private Button startQuizButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        startQuizButton = findViewById(R.id.startQuizButton);

        startQuizButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Correct class name and Intent
                Intent intent = new Intent(principal.this, CategorActivity.class);  // Ensure class name is correct
                startActivity(intent);
                finish();
            }
        });

        Button btngo = findViewById(R.id.button6);
        btngo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(principal.this, User.class);
                startActivity(I);
            }
        });

        Button btnlead = findViewById(R.id.leaderboard);
        btnlead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(principal.this, leaderboard.class);
                startActivity(I);
            }
        });
    }
}
