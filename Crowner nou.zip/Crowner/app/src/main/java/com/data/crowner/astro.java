package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class astro extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(astro.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the closest planet to the Sun?", new String[]{"Earth", "Venus", "Mercury", "Mars"}, 2));
        questions.add(new Question("What galaxy is Earth located in?", new String[]{"Andromeda", "Milky Way", "Whirlpool", "Sombrero"}, 1));
        questions.add(new Question("Which planet is known for its prominent ring system?", new String[]{"Jupiter", "Uranus", "Neptune", "Saturn"}, 3));
        questions.add(new Question("What is the largest planet in our Solar System?", new String[]{"Earth", "Saturn", "Jupiter", "Neptune"}, 2));
        questions.add(new Question("What celestial event occurs when the Moon passes between the Earth and the Sun?", new String[]{"Lunar eclipse", "Solar eclipse", "Equinox", "Transit"}, 1));
        questions.add(new Question("What is the name of the first satellite sent into space?", new String[]{"Apollo 11", "Voyager", "Sputnik", "Hubble"}, 2));
        questions.add(new Question("What is the term for a star that suddenly increases in brightness?", new String[]{"Nova", "Quasar", "Pulsar", "Black hole"}, 0));
        questions.add(new Question("Which planet has the most moons?", new String[]{"Earth", "Saturn", "Jupiter", "Neptune"}, 2));
        questions.add(new Question("What type of galaxy is the Milky Way?", new String[]{"Elliptical", "Spiral", "Irregular", "Barred Spiral"}, 3));
        questions.add(new Question("What is the name of NASA's most famous space telescope?", new String[]{"Hubble", "Kepler", "James Webb", "Chandra"}, 0));
        questions.add(new Question("Which planet is known as the Red Planet?", new String[]{"Venus", "Mars", "Jupiter", "Mercury"}, 1));
        questions.add(new Question("How long does it take the Earth to orbit the Sun?", new String[]{"24 hours", "30 days", "365 days", "12 months"}, 2));
        questions.add(new Question("What is the second brightest object in the night sky after the Moon?", new String[]{"Venus", "Mars", "Jupiter", "Sirius"}, 0));
        questions.add(new Question("What is a light-year a measure of?", new String[]{"Time", "Speed", "Distance", "Brightness"}, 2));
        questions.add(new Question("Which planet is tilted on its side?", new String[]{"Neptune", "Uranus", "Saturn", "Pluto"}, 1));
        questions.add(new Question("Which is the hottest planet in the Solar System?", new String[]{"Mercury", "Mars", "Venus", "Earth"}, 2));
        questions.add(new Question("What force keeps planets in orbit around the Sun?", new String[]{"Magnetism", "Inertia", "Friction", "Gravity"}, 3));
        questions.add(new Question("What do we call the remains of a star that has exploded?", new String[]{"Comet", "Asteroid", "Supernova", "Nebula"}, 2));
        questions.add(new Question("Which spacecraft carried the first humans to the Moon?", new String[]{"Voyager", "Apollo 11", "Challenger", "Discovery"}, 1));
        questions.add(new Question("Which planet has the longest day?", new String[]{"Earth", "Venus", "Mars", "Jupiter"}, 1));
        questions.add(new Question("What is the name of the dwarf planet located in the asteroid belt?", new String[]{"Pluto", "Ceres", "Eris", "Makemake"}, 1));
        questions.add(new Question("Which planet has a Great Red Spot?", new String[]{"Earth", "Neptune", "Jupiter", "Mars"}, 2));
        questions.add(new Question("What is the name of the theory that explains the origin of the universe?", new String[]{"Big Crunch", "Big Bang", "Steady State", "Expansion Theory"}, 1));
        questions.add(new Question("What do we call a rock that reaches Earth's surface from space?", new String[]{"Asteroid", "Meteor", "Meteoroid", "Meteorite"}, 3));
        questions.add(new Question("What is the term for two stars orbiting each other?", new String[]{"Solar pair", "Binary star", "Twin suns", "Double core"}, 1));
        questions.add(new Question("What element is most abundant in stars?", new String[]{"Oxygen", "Carbon", "Hydrogen", "Helium"}, 2));
        questions.add(new Question("Which planet has the fastest rotation?", new String[]{"Earth", "Jupiter", "Mars", "Saturn"}, 1));
        questions.add(new Question("What is the name of Mars's largest moon?", new String[]{"Deimos", "Phobos", "Titan", "Europa"}, 1));
        questions.add(new Question("Which mission first landed humans on the Moon?", new String[]{"Apollo 13", "Apollo 11", "Gemini 8", "Soyuz 1"}, 1));
        questions.add(new Question("What is the farthest planet from the Sun?", new String[]{"Neptune", "Uranus", "Pluto", "Saturn"}, 0));
        questions.add(new Question("What is the surface of the Sun called?", new String[]{"Photosphere", "Chromosphere", "Corona", "Core"}, 0));
        questions.add(new Question("Which planet is known for having a storm called the Great Dark Spot?", new String[]{"Jupiter", "Neptune", "Saturn", "Uranus"}, 1));
        questions.add(new Question("What is the coldest planet in the Solar System?", new String[]{"Pluto", "Neptune", "Uranus", "Mars"}, 2));
        questions.add(new Question("Which constellation contains the North Star?", new String[]{"Orion", "Draco", "Ursa Minor", "Cassiopeia"}, 2));
        questions.add(new Question("What kind of celestial body is the Sun?", new String[]{"Planet", "Star", "Asteroid", "Comet"}, 1));
        questions.add(new Question("Which planet is famous for its bright reflective clouds?", new String[]{"Mars", "Venus", "Neptune", "Mercury"}, 1));
        questions.add(new Question("What part of the Sun is visible during a total solar eclipse?", new String[]{"Core", "Photosphere", "Corona", "Radiative Zone"}, 2));
        questions.add(new Question("How many planets are in the Solar System?", new String[]{"7", "8", "9", "10"}, 1));
        questions.add(new Question("Which moon is the largest in the Solar System?", new String[]{"Ganymede", "Titan", "Europa", "Callisto"}, 0));
        questions.add(new Question("What are Saturn's rings mostly made of?", new String[]{"Gas", "Dust and Ice", "Rock", "Metal"}, 1));
        questions.add(new Question("What is a comet’s tail always pointing away from?", new String[]{"Earth", "The Moon", "The Sun", "Its orbit"}, 2));
        questions.add(new Question("Which planet is closest in size to Earth?", new String[]{"Mars", "Venus", "Mercury", "Uranus"}, 1));
        questions.add(new Question("What was the first living creature sent into space?", new String[]{"Monkey", "Human", "Dog", "Mouse"}, 2));
        questions.add(new Question("How long does light take to travel from the Sun to Earth?", new String[]{"1 second", "8 minutes", "1 hour", "12 minutes"}, 1));
        questions.add(new Question("What shape is the Earth’s orbit around the Sun?", new String[]{"Circular", "Spiral", "Elliptical", "Oval"}, 2));
        questions.add(new Question("Which planet is often called Earth's twin?", new String[]{"Mars", "Mercury", "Venus", "Jupiter"}, 2));
        questions.add(new Question("What causes the phases of the Moon?", new String[]{"Earth's rotation", "Earth's orbit", "Moon's rotation", "Sun’s reflection on the Moon"}, 3));
        questions.add(new Question("What is the term for a moon that completely covers the Sun?", new String[]{"Partial eclipse", "Annular eclipse", "Total eclipse", "Lunar eclipse"}, 2));
        questions.add(new Question("What is the densest planet in the Solar System?", new String[]{"Jupiter", "Earth", "Venus", "Saturn"}, 1));
        questions.add(new Question("How many Earths could fit inside the Sun?", new String[]{"100", "1,000", "10,000", "Over 1 million"}, 3));
        questions.add(new Question("Which space telescope replaced Hubble in 2021?", new String[]{"Spitzer", "Chandra", "James Webb", "Voyager"}, 2));
        questions.add(new Question("Which planet has polar ice caps?", new String[]{"Mercury", "Venus", "Mars", "Jupiter"}, 2));
        questions.add(new Question("What is a pulsar?", new String[]{"A type of comet", "A rapidly spinning neutron star", "A dwarf galaxy", "A gas giant"}, 1));
        questions.add(new Question("How many moons does Earth have?", new String[]{"1", "2", "3", "4"}, 0));
        questions.add(new Question("What is the main component of Jupiter’s atmosphere?", new String[]{"Oxygen", "Carbon dioxide", "Hydrogen", "Nitrogen"}, 2));
        questions.add(new Question("What is the Kuiper Belt?", new String[]{"A star field", "A moon orbit", "A region of icy bodies beyond Neptune", "A planet ring"}, 2));
        questions.add(new Question("Which of these is not a planet?", new String[]{"Pluto", "Earth", "Vesta", "Uranus"}, 2));
        questions.add(new Question("Which planet rotates backwards?", new String[]{"Earth", "Mars", "Venus", "Jupiter"}, 2));
        questions.add(new Question("Which of the following is a gas giant?", new String[]{"Earth", "Mars", "Saturn", "Pluto"}, 2));
        questions.add(new Question("How many stars are in the Solar System?", new String[]{"1", "8", "Thousands", "Millions"}, 0));
        questions.add(new Question("What is the most common type of star?", new String[]{"Red giant", "White dwarf", "Red dwarf", "Blue giant"}, 2));
        questions.add(new Question("What is the name of the layer of the Sun just above the core?", new String[]{"Photosphere", "Radiative zone", "Convective zone", "Corona"}, 1));
        questions.add(new Question("Which planet has the highest mountain in the Solar System?", new String[]{"Earth", "Mars", "Venus", "Jupiter"}, 1));
        questions.add(new Question("What is the term for planets outside our Solar System?", new String[]{"Exoplanets", "Megaplanets", "Alien worlds", "Interstellar bodies"}, 0));
        questions.add(new Question("What’s the primary cause of tides on Earth?", new String[]{"The Sun", "The Moon", "Wind", "Plate movement"}, 1));
        questions.add(new Question("Which mission sent a rover to Mars in 2021?", new String[]{"Curiosity", "Viking", "Spirit", "Perseverance"}, 3));
        questions.add(new Question("What is the name of Saturn’s largest moon?", new String[]{"Io", "Europa", "Titan", "Phobos"}, 2));
        questions.add(new Question("What protects Earth from solar wind?", new String[]{"Ozone Layer", "Atmosphere", "Gravity", "Magnetosphere"}, 3));
        questions.add(new Question("Which gas makes Uranus and Neptune blue?", new String[]{"Oxygen", "Methane", "Nitrogen", "Carbon dioxide"}, 1));
        questions.add(new Question("What is the term for the death of a massive star?", new String[]{"Nova", "Supernova", "Collapse", "Quasar"}, 1));
        questions.add(new Question("Which planet has seasons similar to Earth?", new String[]{"Jupiter", "Venus", "Mars", "Mercury"}, 2));
        questions.add(new Question("What is the asteroid belt located between?", new String[]{"Earth and Mars", "Jupiter and Saturn", "Mars and Jupiter", "Venus and Earth"}, 2));
        questions.add(new Question("What is the smallest planet in the Solar System?", new String[]{"Mars", "Mercury", "Pluto", "Venus"}, 1));
        questions.add(new Question("What do you call the point in a planet’s orbit closest to the Sun?", new String[]{"Aphelion", "Perihelion", "Zenith", "Ecliptic"}, 1));
        questions.add(new Question("What is the approximate age of the universe?", new String[]{"1 billion years", "4.6 billion years", "13.8 billion years", "100 billion years"}, 2));
        questions.add(new Question("What planet has the most eccentric orbit?", new String[]{"Mercury", "Mars", "Pluto", "Neptune"}, 2));
        questions.add(new Question("Which planet was demoted to dwarf status in 2006?", new String[]{"Eris", "Pluto", "Ceres", "Makemake"}, 1));
        questions.add(new Question("What’s at the center of the Milky Way?", new String[]{"A star", "A planet", "A supermassive black hole", "A nebula"}, 2));
        questions.add(new Question("What is a solar flare?", new String[]{"A comet passing the Sun", "A bright star", "An eruption on the Sun’s surface", "A light reflection"}, 2));
        questions.add(new Question("How many Apollo missions landed on the Moon?", new String[]{"3", "5", "6", "7"}, 2));
        questions.add(new Question("What is the heliosphere?", new String[]{"The Sun’s core", "Solar wind boundary", "Sun’s atmosphere", "Earth's orbit"}, 1));
        questions.add(new Question("What shape are most galaxies?", new String[]{"Elliptical", "Spiral", "Irregular", "All of the above"}, 3));
        questions.add(new Question("What is parallax used to measure?", new String[]{"Mass", "Time", "Distance to stars", "Brightness"}, 2));
        questions.add(new Question("What is the most famous comet visible from Earth every 76 years?", new String[]{"Halley’s Comet", "Encke", "Shoemaker-Levy", "Neowise"}, 0));
        questions.add(new Question("What is the name of the boundary around a black hole?", new String[]{"Gravitational lens", "Photon sphere", "Event horizon", "Singularity"}, 2));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
