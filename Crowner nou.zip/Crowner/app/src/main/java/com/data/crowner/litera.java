package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class litera extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(litera.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("Who wrote the novel '1984'?", new String[]{"George Orwell", "Aldous Huxley", "Ray Bradbury", "J.R.R. Tolkien"}, 0));
        questions.add(new Question("Who is the author of 'Pride and Prejudice'?", new String[]{"Jane Austen", "Emily Brontë", "Charlotte Brontë", "Mary Shelley"}, 0));
        questions.add(new Question("In which novel does the character Atticus Finch appear?", new String[]{"To Kill a Mockingbird", "The Great Gatsby", "Of Mice and Men", "The Catcher in the Rye"}, 0));
        questions.add(new Question("Who wrote 'The Catcher in the Rye'?", new String[]{"J.D. Salinger", "F. Scott Fitzgerald", "John Steinbeck", "Ernest Hemingway"}, 0));
        questions.add(new Question("Which novel begins with the line 'Call me Ishmael'?", new String[]{"Moby-Dick", "The Great Gatsby", "The Old Man and the Sea", "Frankenstein"}, 0));
        questions.add(new Question("Who is the author of 'The Odyssey'?", new String[]{"Homer", "Virgil", "Sophocles", "Euripides"}, 0));
        questions.add(new Question("Which novel is set in the fictional town of Maycomb, Alabama?", new String[]{"To Kill a Mockingbird", "The Grapes of Wrath", "The Sound and the Fury", "Of Mice and Men"}, 0));
        questions.add(new Question("In which novel does the character Big Brother appear?", new String[]{"1984", "Brave New World", "Fahrenheit 451", "The Handmaid's Tale"}, 0));
        questions.add(new Question("Who wrote 'The Great Gatsby'?", new String[]{"F. Scott Fitzgerald", "Ernest Hemingway", "William Faulkner", "John Steinbeck"}, 0));
        questions.add(new Question("Who is the author of 'Frankenstein'?", new String[]{"Mary Shelley", "Charles Dickens", "Emily Brontë", "Edgar Allan Poe"}, 0));
        questions.add(new Question("What is the title of the first Harry Potter book?", new String[]{"Harry Potter and the Philosopher's Stone", "Harry Potter and the Chamber of Secrets", "Harry Potter and the Prisoner of Azkaban", "Harry Potter and the Goblet of Fire"}, 0));
        questions.add(new Question("Which author created the character Sherlock Holmes?", new String[]{"Arthur Conan Doyle", "Agatha Christie", "Edgar Allan Poe", "Dashiell Hammett"}, 0));
        questions.add(new Question("Who wrote 'The Lord of the Rings' trilogy?", new String[]{"J.R.R. Tolkien", "C.S. Lewis", "J.K. Rowling", "Philip Pullman"}, 0));
        questions.add(new Question("Which novel is set during the Russian Revolution?", new String[]{"Animal Farm", "War and Peace", "The Brothers Karamazov", "Doctor Zhivago"}, 0));
        questions.add(new Question("Who wrote 'The Picture of Dorian Gray'?", new String[]{"Oscar Wilde", "Virginia Woolf", "Charles Dickens", "Mark Twain"}, 0));
        questions.add(new Question("Which author wrote 'The Hobbit'?", new String[]{"J.R.R. Tolkien", "C.S. Lewis", "J.K. Rowling", "George R.R. Martin"}, 0));
        questions.add(new Question("What is the name of the detective in Agatha Christie's novels?", new String[]{"Hercule Poirot", "Sherlock Holmes", "Sam Spade", "Philip Marlowe"}, 0));
        questions.add(new Question("Who wrote 'Brave New World'?", new String[]{"Aldous Huxley", "Ray Bradbury", "George Orwell", "Kurt Vonnegut"}, 0));
        questions.add(new Question("Who wrote 'Wuthering Heights'?", new String[]{"Emily Brontë", "Charlotte Brontë", "Jane Austen", "Mary Shelley"}, 0));
        questions.add(new Question("Who is the author of 'Jane Eyre'?", new String[]{"Charlotte Brontë", "Emily Brontë", "Mary Shelley", "Louisa May Alcott"}, 0));
        questions.add(new Question("Which novel begins with the line, 'It was the best of times, it was the worst of times'?", new String[]{"A Tale of Two Cities", "Les Misérables", "The Great Expectations", "David Copperfield"}, 0));
        questions.add(new Question("Who wrote 'Moby-Dick'?", new String[]{"Herman Melville", "Nathaniel Hawthorne", "Mark Twain", "Edgar Allan Poe"}, 0));
        questions.add(new Question("Who wrote 'Dracula'?", new String[]{"Bram Stoker", "Mary Shelley", "Robert Louis Stevenson", "Edgar Allan Poe"}, 0));
        questions.add(new Question("Who is the author of 'The Brothers Karamazov'?", new String[]{"Fyodor Dostoevsky", "Leo Tolstoy", "Anton Chekhov", "Maxim Gorky"}, 0));
        questions.add(new Question("Who wrote 'The Divine Comedy'?", new String[]{"Dante Alighieri", "Homer", "Virgil", "John Milton"}, 0));
        questions.add(new Question("Who wrote 'The Scarlet Letter'?", new String[]{"Nathaniel Hawthorne", "Mark Twain", "Henry James", "Herman Melville"}, 0));
        questions.add(new Question("Who wrote 'The Iliad'?", new String[]{"Homer", "Virgil", "Sophocles", "Euripides"}, 0));
        questions.add(new Question("Who wrote 'Catch-22'?", new String[]{"Joseph Heller", "Kurt Vonnegut", "John Steinbeck", "Ernest Hemingway"}, 0));
        questions.add(new Question("Who wrote 'The Grapes of Wrath'?", new String[]{"John Steinbeck", "Ernest Hemingway", "William Faulkner", "F. Scott Fitzgerald"}, 0));
        questions.add(new Question("Which author is known for writing dystopian novels, including 'Fahrenheit 451'?", new String[]{"Ray Bradbury", "Aldous Huxley", "George Orwell", "Kurt Vonnegut"}, 0));
        questions.add(new Question("Who wrote 'The Catcher in the Rye'?", new String[]{"J.D. Salinger", "John Steinbeck", "Mark Twain", "F. Scott Fitzgerald"}, 0));
        questions.add(new Question("Who wrote 'The Road'?", new String[]{"Cormac McCarthy", "Philip Roth", "John Updike", "Thomas Pynchon"}, 0));
        questions.add(new Question("Who wrote 'The Hunger Games'?", new String[]{"Suzanne Collins", "Veronica Roth", "J.K. Rowling", "Stephenie Meyer"}, 0));
        questions.add(new Question("Which novel features the character Holden Caulfield?", new String[]{"The Catcher in the Rye", "The Great Gatsby", "The Grapes of Wrath", "Of Mice and Men"}, 0));
        questions.add(new Question("Who wrote 'The Sun Also Rises'?", new String[]{"Ernest Hemingway", "William Faulkner", "John Steinbeck", "F. Scott Fitzgerald"}, 0));
        questions.add(new Question("Which author wrote the 'Chronicles of Narnia' series?", new String[]{"C.S. Lewis", "J.K. Rowling", "J.R.R. Tolkien", "Philip Pullman"}, 0));
        questions.add(new Question("Who wrote 'The Bell Jar'?", new String[]{"Sylvia Plath", "Virginia Woolf", "Emily Dickinson", "Toni Morrison"}, 0));
        questions.add(new Question("Who wrote 'One Hundred Years of Solitude'?", new String[]{"Gabriel García Márquez", "Mario Vargas Llosa", "Isabel Allende", "Carlos Fuentes"}, 0));
        questions.add(new Question("Who wrote 'The Handmaid's Tale'?", new String[]{"Margaret Atwood", "Toni Morrison", "Aldous Huxley", "George Orwell"}, 0));
        questions.add(new Question("Who wrote 'Beloved'?", new String[]{"Toni Morrison", "Alice Walker", "Zora Neale Hurston", "Maya Angelou"}, 0));
        questions.add(new Question("Who wrote 'The Great Gatsby'?", new String[]{"F. Scott Fitzgerald", "Ernest Hemingway", "John Steinbeck", "William Faulkner"}, 0));
        questions.add(new Question("Who wrote 'A Game of Thrones'?", new String[]{"George R.R. Martin", "J.K. Rowling", "J.R.R. Tolkien", "Philip Pullman"}, 0));
        questions.add(new Question("Who wrote 'The Fault in Our Stars'?", new String[]{"John Green", "Stephen King", "J.K. Rowling", "Nicholas Sparks"}, 0));
        questions.add(new Question("Who wrote 'The Outsiders'?", new String[]{"S.E. Hinton", "J.K. Rowling", "John Green", "Toni Morrison"}, 0));
        questions.add(new Question("Who wrote 'Frankenstein'?", new String[]{"Mary Shelley", "Bram Stoker", "Edgar Allan Poe", "Oscar Wilde"}, 0));
        questions.add(new Question("Who wrote 'The Shining'?", new String[]{"Stephen King", "Edgar Allan Poe", "H.P. Lovecraft", "Clive Barker"}, 0));
        questions.add(new Question("Who wrote 'The Color Purple'?", new String[]{"Alice Walker", "Toni Morrison", "Maya Angelou", "Zora Neale Hurston"}, 0));
        questions.add(new Question("Who wrote 'Brave New World'?", new String[]{"Aldous Huxley", "Ray Bradbury", "Kurt Vonnegut", "George Orwell"}, 0));
        questions.add(new Question("Who wrote 'The Hobbit'?", new String[]{"J.R.R. Tolkien", "C.S. Lewis", "Philip Pullman", "George R.R. Martin"}, 0));
        questions.add(new Question("Who wrote 'The Trial'?", new String[]{"Franz Kafka", "Herman Hesse", "Albert Camus", "Jean-Paul Sartre"}, 0));
        questions.add(new Question("Who wrote 'Wicked'?", new String[]{"Gregory Maguire", "J.K. Rowling", "Philip Pullman", "C.S. Lewis"}, 0));
        questions.add(new Question("Who wrote 'Catch-22'?", new String[]{"Joseph Heller", "Kurt Vonnegut", "John Steinbeck", "Ernest Hemingway"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
