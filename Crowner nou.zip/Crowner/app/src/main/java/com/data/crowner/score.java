package com.data.crowner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class score extends AppCompatActivity {

    private TextView finalScoreText, crownMessageText;  // Added TextView for crown message
    private Button restartButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        finalScoreText = findViewById(R.id.finalScoreText);
        crownMessageText = findViewById(R.id.crownMessageText);  // Initialize the crown message TextView
        restartButton = findViewById(R.id.restartButton);

        // Get the score passed from MainActivity
        int finalScore = getIntent().getIntExtra("finalScore", 0);

        // Display the score
        finalScoreText.setText("Your Score: " + finalScore);

        // Add logic to display the crown message based on the score
        if (finalScore < 85) {
            crownMessageText.setText("Aw! You received no crowns.\uD83D\uDE14");
        } else if (finalScore >= 85 && finalScore <= 95) {
            crownMessageText.setText("Nice! You received 1 crown!\uD83D\uDC51");
        } else if (finalScore == 100) {
            crownMessageText.setText("OMG! You received 2 crowns!\uD83D\uDC51\uD83D\uDC51");
        }

        // Set up the restart button
        restartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Restart the quiz by going to the MainScreenActivity
                Intent restartIntent = new Intent(score.this, principal.class);
                startActivity(restartIntent);
                finish(); // Close the FinalActivity
            }
        });
    }
}