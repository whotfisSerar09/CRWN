package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class physics extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(physics.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the unit of force?", new String[]{"Newton", "Joule", "Watt", "Pascal"}, 0));
        questions.add(new Question("What is the speed of light in a vacuum?", new String[]{"3 × 10^8 m/s", "3 × 10^6 m/s", "3 × 10^7 m/s", "3 × 10^9 m/s"}, 0));
        questions.add(new Question("What is the law that states 'For every action, there is an equal and opposite reaction'?", new String[]{"Newton's Third Law", "Newton's First Law", "Newton's Second Law", "Hooke's Law"}, 0));
        questions.add(new Question("What is the acceleration due to gravity on Earth?", new String[]{"9.8 m/s²", "10 m/s²", "8.9 m/s²", "9.5 m/s²"}, 0));
        questions.add(new Question("What is the formula for kinetic energy?", new String[]{"(1/2)mv²", "(1/2)mv", "mgh", "mv²"}, 0));
        questions.add(new Question("Which of the following is an example of a vector quantity?", new String[]{"Velocity", "Speed", "Distance", "Mass"}, 0));
        questions.add(new Question("What is the unit of electric current?", new String[]{"Ampere", "Volt", "Ohm", "Coulomb"}, 0));
        questions.add(new Question("What type of energy is stored in a compressed spring?", new String[]{"Potential energy", "Kinetic energy", "Thermal energy", "Electrical energy"}, 0));
        questions.add(new Question("What is the phenomenon that causes objects to float in water?", new String[]{"Buoyancy", "Friction", "Inertia", "Elasticity"}, 0));
        questions.add(new Question("What is the force that opposes motion between two surfaces in contact?", new String[]{"Friction", "Gravity", "Magnetism", "Elastic force"}, 0));
        questions.add(new Question("Which particle is negatively charged?", new String[]{"Electron", "Proton", "Neutron", "Positron"}, 0));
        questions.add(new Question("What is the principle behind the operation of a lever?", new String[]{"Mechanical advantage", "Conservation of energy", "Action and reaction", "Work-energy theorem"}, 0));
        questions.add(new Question("What is the energy of motion called?", new String[]{"Kinetic energy", "Potential energy", "Thermal energy", "Chemical energy"}, 0));
        questions.add(new Question("What does Ohm's law relate?", new String[]{"Voltage, current, and resistance", "Force, mass, and acceleration", "Pressure, volume, and temperature", "Mass and energy"}, 0));
        questions.add(new Question("What type of wave is light?", new String[]{"Electromagnetic wave", "Sound wave", "Mechanical wave", "Water wave"}, 0));
        questions.add(new Question("What is the unit of power?", new String[]{"Watt", "Joule", "Newton", "Pascal"}, 0));
        questions.add(new Question("What is the first law of thermodynamics?", new String[]{"Energy cannot be created or destroyed", "Energy is conserved", "Heat flows from hot to cold", "Work done is equal to the change in energy"}, 0));
        questions.add(new Question("Which of these is the main cause of tides?", new String[]{"The Moon's gravity", "The Sun's gravity", "Earth's rotation", "Ocean currents"}, 0));
        questions.add(new Question("What is the formula for force?", new String[]{"F = ma", "F = mv", "F = mgh", "F = 1/2mv²"}, 0));
        questions.add(new Question("What type of energy is associated with an object's position?", new String[]{"Potential energy", "Kinetic energy", "Thermal energy", "Sound energy"}, 0));
        questions.add(new Question("What does a magnetic field do?", new String[]{"Attracts or repels magnetic materials", "Attracts metals", "Conducts electricity", "Creates heat"}, 0));
        questions.add(new Question("What is the SI unit for mass?", new String[]{"Kilogram", "Gram", "Pound", "Ounce"}, 0));
        questions.add(new Question("What is the term for the bending of light as it passes from one medium to another?", new String[]{"Refraction", "Reflection", "Diffraction", "Absorption"}, 0));
        questions.add(new Question("What type of material has free electrons that can move?", new String[]{"Conductor", "Insulator", "Semiconductor", "Superconductor"}, 0));
        questions.add(new Question("What is the energy stored in an object due to its motion?", new String[]{"Kinetic energy", "Potential energy", "Thermal energy", "Nuclear energy"}, 0));
        questions.add(new Question("What is the principle of conservation of momentum?", new String[]{"Momentum remains constant in a closed system", "Energy cannot be created or destroyed", "The total energy of a system is constant", "Forces are equal and opposite"}, 0));
        questions.add(new Question("What happens when a moving object slows down?", new String[]{"It loses kinetic energy", "It gains potential energy", "It loses potential energy", "It gains kinetic energy"}, 0));
        questions.add(new Question("What is the main difference between longitudinal and transverse waves?", new String[]{"Direction of particle motion", "Amplitude", "Frequency", "Wavelength"}, 0));
        questions.add(new Question("Which particle is found in the nucleus of an atom?", new String[]{"Proton", "Electron", "Neutron", "Photon"}, 0));
        questions.add(new Question("What is the term for the rate of change of velocity?", new String[]{"Acceleration", "Velocity", "Speed", "Force"}, 0));
        questions.add(new Question("Which law states that the pressure of a gas is inversely proportional to its volume?", new String[]{"Boyle's Law", "Charles's Law", "Newton's Law", "Hooke's Law"}, 0));
        questions.add(new Question("What is the device that converts electrical energy to mechanical energy?", new String[]{"Motor", "Generator", "Battery", "Capacitor"}, 0));
        questions.add(new Question("What is the unit of electric charge?", new String[]{"Coulomb", "Ampere", "Volt", "Ohm"}, 0));
        questions.add(new Question("What is the relationship between force, mass, and acceleration?", new String[]{"F = ma", "F = mv", "F = mgh", "F = 1/2mv²"}, 0));
        questions.add(new Question("What is the principle of superposition in waves?", new String[]{"The displacement is the sum of the displacements of the individual waves", "Waves cannot pass through each other", "The amplitude of a wave is constant", "Waves always cancel out"}, 0));
        questions.add(new Question("What is the unit of frequency?", new String[]{"Hertz", "Newton", "Joule", "Ampere"}, 0));
        questions.add(new Question("What is the term for the amount of matter in an object?", new String[]{"Mass", "Weight", "Density", "Volume"}, 0));
        questions.add(new Question("What is the device that stores energy in an electric field?", new String[]{"Capacitor", "Inductor", "Resistor", "Transistor"}, 0));
        questions.add(new Question("What type of waves do cell phones use?", new String[]{"Radio waves", "Microwaves", "Infrared waves", "X-rays"}, 0));
        questions.add(new Question("What is the formula for potential energy?", new String[]{"PE = mgh", "PE = 1/2mv²", "PE = Fd", "PE = mv²"}, 0));
        questions.add(new Question("What is the unit of pressure?", new String[]{"Pascal", "Joule", "Watt", "Newton"}, 0));
        questions.add(new Question("What is the theory that describes the behavior of particles on the atomic scale?", new String[]{"Quantum mechanics", "Relativity", "Thermodynamics", "Electrodynamics"}, 0));
        questions.add(new Question("What is the phenomenon that occurs when light is absorbed and re-emitted by an atom?", new String[]{"Fluorescence", "Refraction", "Reflection", "Diffraction"}, 0));
        questions.add(new Question("What is the relationship between current, voltage, and resistance?", new String[]{"Ohm's Law", "Faraday's Law", "Coulomb's Law", "Ampere's Law"}, 0));
        questions.add(new Question("What is the property of matter that resists changes in motion?", new String[]{"Inertia", "Friction", "Momentum", "Velocity"}, 0));
        questions.add(new Question("What is the law that states that energy cannot be created or destroyed?", new String[]{"First law of thermodynamics", "Second law of thermodynamics", "Law of conservation of momentum", "Law of conservation of energy"}, 0));
        questions.add(new Question("What is the term for the total energy of an object due to its motion and position?", new String[]{"Mechanical energy", "Thermal energy", "Kinetic energy", "Potential energy"}, 0));
        questions.add(new Question("What is the unit of magnetic flux?", new String[]{"Weber", "Tesla", "Ampere", "Volt"}, 0));
        questions.add(new Question("What is the formula for calculating work?", new String[]{"W = Fd", "W = ma", "W = mv", "W = P/V"}, 0));
        questions.add(new Question("What type of electromagnetic waves have the shortest wavelengths?", new String[]{"Gamma rays", "X-rays", "Ultraviolet", "Radio waves"}, 0));
        questions.add(new Question("What is the phenomenon of light bending around obstacles?", new String[]{"Diffraction", "Refraction", "Reflection", "Absorption"}, 0));
        questions.add(new Question("Which of the following is a non-renewable energy source?", new String[]{"Coal", "Wind", "Solar", "Geothermal"}, 0));
        questions.add(new Question("What is the name for the process of splitting an atomic nucleus?", new String[]{"Nuclear fission", "Nuclear fusion", "Radioactive decay", "Ionization"}, 0));
        questions.add(new Question("What is the unit of energy?", new String[]{"Joule", "Watt", "Pascal", "Newton"}, 0));
        questions.add(new Question("Which type of wave can travel through a vacuum?", new String[]{"Electromagnetic wave", "Mechanical wave", "Sound wave", "Water wave"}, 0));
        questions.add(new Question("What is the principle behind a transformer?", new String[]{"Electromagnetic induction", "Electric field", "Magnetic field", "Conservation of energy"}, 0));
        questions.add(new Question("What is the value of the universal gravitational constant?", new String[]{"6.674 × 10^-11 N·m²/kg²", "9.8 m/s²", "8.99 × 10⁹ N·m²/C²", "3.00 × 10^8 m/s"}, 0));
        questions.add(new Question("What is the primary difference between transverse and longitudinal waves?", new String[]{"Direction of particle motion", "Speed", "Amplitude", "Frequency"}, 0));
        questions.add(new Question("What is the SI unit for temperature?", new String[]{"Kelvin", "Celsius", "Fahrenheit", "Joule"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
