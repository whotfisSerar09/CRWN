package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class art extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(art.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("Who painted the Sistine Chapel ceiling?", new String[]{"Raphael", "Michelangelo", "Donatello", "Caravaggio"}, 1));
        questions.add(new Question("Which artist is known for the painting 'Starry Night'?", new String[]{"Monet", "Van Gogh", "Matisse", "Cézanne"}, 1));
        questions.add(new Question("What type of sculpture is Michelangelo's 'David'?", new String[]{"Bronze", "Marble", "Wood", "Granite"}, 1));
        questions.add(new Question("Which famous artist is known for the Blue Period?", new String[]{"Picasso", "Van Gogh", "Gauguin", "Dali"}, 0));
        questions.add(new Question("What country is the origin of ukiyo-e woodblock prints?", new String[]{"China", "Japan", "Korea", "Thailand"}, 1));
        questions.add(new Question("Who sculpted 'The Thinker'?", new String[]{"Rodin", "Michelangelo", "Bernini", "Moore"}, 0));
        questions.add(new Question("What art movement is Salvador Dalí associated with?", new String[]{"Cubism", "Surrealism", "Impressionism", "Futurism"}, 1));
        questions.add(new Question("What is the primary medium of fresco painting?", new String[]{"Oil", "Acrylic", "Wet plaster", "Canvas"}, 2));
        questions.add(new Question("Which building houses the 'Mona Lisa'?", new String[]{"The Met", "The Louvre", "Uffizi", "Tate"}, 1));
        questions.add(new Question("Which artist is famous for his 'Campbell's Soup Cans'?", new String[]{"Warhol", "Lichtenstein", "Pollock", "Hockney"}, 0));
        questions.add(new Question("What is the name of the art style using tiny dots of color?", new String[]{"Cubism", "Pointillism", "Impressionism", "Expressionism"}, 1));
        questions.add(new Question("Who painted 'The Persistence of Memory'?", new String[]{"Ernst", "Dalí", "Magritte", "Miro"}, 1));
        questions.add(new Question("Which period followed the Renaissance in European art?", new String[]{"Baroque", "Neoclassical", "Gothic", "Romanticism"}, 0));
        questions.add(new Question("Which Dutch artist is known for geometric abstract art?", new String[]{"Mondrian", "Rembrandt", "Van Gogh", "Vermeer"}, 0));
        questions.add(new Question("What material is traditionally used for bronze sculptures?", new String[]{"Iron", "Tin", "Bronze", "Steel"}, 2));
        questions.add(new Question("Who painted 'The Night Watch'?", new String[]{"Vermeer", "Rembrandt", "Rubens", "Hals"}, 1));
        questions.add(new Question("What style is characterized by exaggerated motion and clear detail?", new String[]{"Baroque", "Minimalism", "Cubism", "Futurism"}, 0));
        questions.add(new Question("Which artist is known for melting clocks in their paintings?", new String[]{"Magritte", "Dalí", "Picasso", "Klee"}, 1));
        questions.add(new Question("What is the term for painting on wet plaster?", new String[]{"Fresco", "Tempera", "Encaustic", "Gouache"}, 0));
        questions.add(new Question("Which museum is located in Florence and holds Renaissance art?", new String[]{"Louvre", "Prado", "Uffizi", "National Gallery"}, 2));
        questions.add(new Question("What is the medium of 'The Birth of Venus'?", new String[]{"Oil on canvas", "Tempera on canvas", "Tempera on wood", "Fresco"}, 1));
        questions.add(new Question("Which movement includes artists like Kandinsky and Malevich?", new String[]{"Expressionism", "Suprematism", "Cubism", "Dada"}, 1));
        questions.add(new Question("Who painted 'Girl with a Pearl Earring'?", new String[]{"Rembrandt", "Vermeer", "Rubens", "Fragonard"}, 1));
        questions.add(new Question("What is the name of Picasso’s anti-war painting?", new String[]{"Guernica", "Les Demoiselles", "The Weeping Woman", "The Old Guitarist"}, 0));
        questions.add(new Question("Which technique involves carving into a surface to make prints?", new String[]{"Lithography", "Engraving", "Screen printing", "Etching"}, 1));
        questions.add(new Question("Who painted 'The Garden of Earthly Delights'?", new String[]{"Bruegel", "Bosch", "Grünewald", "Giotto"}, 1));
        questions.add(new Question("Which building is known for its dome painted by Brunelleschi?", new String[]{"St. Peter’s Basilica", "Florence Cathedral", "Pantheon", "St. Paul's"}, 1));
        questions.add(new Question("Which artist is associated with the mobile sculpture?", new String[]{"Calder", "Moore", "Rodin", "Giacometti"}, 0));
        questions.add(new Question("What movement was Jackson Pollock part of?", new String[]{"Impressionism", "Abstract Expressionism", "Cubism", "Realism"}, 1));
        questions.add(new Question("Who is known for colorful pop art portraits of Marilyn Monroe?", new String[]{"Warhol", "Lichtenstein", "Haring", "Basquiat"}, 0));
        questions.add(new Question("What style uses geometric forms and multiple perspectives?", new String[]{"Cubism", "Futurism", "Surrealism", "Expressionism"}, 0));
        questions.add(new Question("What sculpture is found in the Louvre and is headless?", new String[]{"Venus de Milo", "Winged Victory of Samothrace", "David", "Discobolus"}, 1));
        questions.add(new Question("Who painted 'Water Lilies'?", new String[]{"Manet", "Monet", "Seurat", "Pissarro"}, 1));
        questions.add(new Question("Who sculpted 'Pietà'?", new String[]{"Donatello", "Michelangelo", "Bernini", "Cellini"}, 1));
        questions.add(new Question("Which country is famous for terracotta warriors?", new String[]{"Japan", "India", "China", "Korea"}, 2));
        questions.add(new Question("Which 20th-century movement emphasized 'automatic drawing'?", new String[]{"Cubism", "Surrealism", "Expressionism", "Fauvism"}, 1));
        questions.add(new Question("Which artist was known for using cut-out paper shapes?", new String[]{"Klee", "Matisse", "Chagall", "Hopper"}, 1));
        questions.add(new Question("Which ancient civilization built the Parthenon?", new String[]{"Romans", "Greeks", "Egyptians", "Persians"}, 1));
        questions.add(new Question("Who painted 'American Gothic'?", new String[]{"Grant Wood", "Edward Hopper", "Norman Rockwell", "Georgia O’Keeffe"}, 0));
        questions.add(new Question("What is a diptych?", new String[]{"A statue", "A two-panel painting", "A mosaic", "A ceiling fresco"}, 1));
        questions.add(new Question("Which painter is associated with color field painting?", new String[]{"Rothko", "Pollock", "Mondrian", "Kandinsky"}, 0));
        questions.add(new Question("Which movement is characterized by strong color and rough brushwork?", new String[]{"Cubism", "Fauvism", "Minimalism", "Constructivism"}, 1));
        questions.add(new Question("What is chiaroscuro?", new String[]{"Light and dark contrast", "Perspective technique", "Color blocking", "Shadow painting"}, 0));
        questions.add(new Question("Which painter is known for dramatic use of light?", new String[]{"Rembrandt", "Turner", "Monet", "Degas"}, 0));
        questions.add(new Question("What are mosaics made of?", new String[]{"Paint", "Glass tiles", "Marble dust", "Sand"}, 1));
        questions.add(new Question("Which Roman building is known for its dome?", new String[]{"Pantheon", "Colosseum", "Forum", "Aqueduct"}, 0));
        questions.add(new Question("Which Egyptian sculpture is half-human, half-lion?", new String[]{"Obelisk", "Sphinx", "Scarab", "Mummy"}, 1));
        questions.add(new Question("What is the main material of stained glass?", new String[]{"Ceramic", "Glass", "Plastic", "Metal"}, 1));
        questions.add(new Question("Who painted 'Liberty Leading the People'?", new String[]{"David", "Delacroix", "Géricault", "Ingres"}, 1));
        questions.add(new Question("Who painted 'The School of Athens'?", new String[]{"Raphael", "Leonardo", "Michelangelo", "Titian"}, 0));
        questions.add(new Question("Which painter is known for ballerina subjects?", new String[]{"Manet", "Degas", "Renoir", "Cézanne"}, 1));
        questions.add(new Question("Who painted 'The Kiss'?", new String[]{"Munch", "Klimt", "Schiele", "Bosch"}, 1));
        questions.add(new Question("Which Renaissance artist was also a scientist?", new String[]{"Raphael", "Da Vinci", "Donatello", "Caravaggio"}, 1));
        questions.add(new Question("What is trompe-l'œil?", new String[]{"A sculpture style", "A style of painting to trick the eye", "A pigment", "A brush technique"}, 1));
        questions.add(new Question("Who painted 'The Scream'?", new String[]{"Munch", "Dali", "Magritte", "Goya"}, 0));
        questions.add(new Question("Who painted the 'Last Supper'?", new String[]{"Da Vinci", "Michelangelo", "Raphael", "Botticelli"}, 0));
        questions.add(new Question("Which style of painting emphasizes light and color over detail?", new String[]{"Impressionism", "Realism", "Surrealism", "Cubism"}, 0));
        questions.add(new Question("Who sculpted the 'Ecstasy of Saint Teresa'?", new String[]{"Bernini", "Michelangelo", "Donatello", "Rodin"}, 0));
        questions.add(new Question("What is the purpose of a 'plein air' painting?", new String[]{"To paint from memory", "To paint outdoors", "To create a still life", "To use digital tools"}, 1));
        questions.add(new Question("Which Renaissance artist is known for his studies of human anatomy?", new String[]{"Michelangelo", "Da Vinci", "Raphael", "Titian"}, 1));
        questions.add(new Question("What technique does a mosaic use?", new String[]{"Coloring", "Shading", "Tile arrangement", "Brushing"}, 2));
        questions.add(new Question("What is the term for the outer boundary of a painting?", new String[]{"Frame", "Border", "Mat", "Edge"}, 0));
        questions.add(new Question("Who is known for the 'Guernica' painting?", new String[]{"Picasso", "Dali", "Matisse", "Kandinsky"}, 0));
        questions.add(new Question("What is the term for a sculpture created by removing material?", new String[]{"Casting", "Modeling", "Carving", "Assembling"}, 2));
        questions.add(new Question("What medium was used in the creation of the 'Mona Lisa'?", new String[]{"Acrylic", "Oil on canvas", "Tempera", "Watercolor"}, 1));
        questions.add(new Question("What is a common material used in modern abstract sculpture?", new String[]{"Wood", "Stone", "Bronze", "Plastic"}, 3));
        questions.add(new Question("What color is most often associated with 'fauvism'?", new String[]{"Red", "Green", "Blue", "Bright colors"}, 3));
        questions.add(new Question("What is the primary focus of surrealist paintings?", new String[]{"Nature", "The unconscious mind", "Political messages", "Mathematics"}, 1));
        questions.add(new Question("What is the name of the art technique that uses paint to create an optical illusion of depth?", new String[]{"Trompe-l'œil", "Cubism", "Impressionism", "Expressionism"}, 0));
        questions.add(new Question("Which artist is known for creating 'The Persistence of Memory'?", new String[]{"Dali", "Picasso", "Magritte", "Van Gogh"}, 0));
        questions.add(new Question("Who painted 'The Girl with a Pearl Earring'?", new String[]{"Vermeer", "Rembrandt", "Van Gogh", "Da Vinci"}, 0));
        questions.add(new Question("Which artist is associated with the art movement known as 'Fauvism'?", new String[]{"Van Gogh", "Monet", "Matisse", "Cézanne"}, 2));
        questions.add(new Question("Which artist was known for his abstract geometric paintings?", new String[]{"Pollock", "Mondrian", "Picasso", "Van Gogh"}, 1));
        questions.add(new Question("Which style of art focuses on geometric abstraction and multi-perspective?", new String[]{"Cubism", "Dada", "Baroque", "Surrealism"}, 0));
        questions.add(new Question("What does 'Renaissance' mean in the context of art?", new String[]{"Renewal of classical learning and art", "Style of bright colors", "Dark, moody realism", "A movement for self-expression"}, 0));
        questions.add(new Question("Which sculpture represents a biblical hero fighting a giant?", new String[]{"David", "Hercules", "The Thinker", "Venus de Milo"}, 0));
        questions.add(new Question("Who painted 'Las Meninas'?", new String[]{"Velázquez", "Goya", "El Greco", "Murillo"}, 0));
        questions.add(new Question("Which artist painted 'The Birth of Venus'?", new String[]{"Raphael", "Botticelli", "Da Vinci", "Michelangelo"}, 1));
        questions.add(new Question("Who is known for creating abstract works using large, vibrant color blocks?", new String[]{"Rothko", "Pollock", "Warhol", "Haring"}, 0));
        questions.add(new Question("Which art movement is characterized by spontaneity and an emphasis on the subconscious?", new String[]{"Surrealism", "Cubism", "Realism", "Impressionism"}, 0));
        questions.add(new Question("What was the name of the artistic movement that challenged traditional representations and emphasized abstract forms?", new String[]{"Cubism", "Surrealism", "Renaissance", "Baroque"}, 0));
        questions.add(new Question("Which artist is associated with the 'Pop Art' movement?", new String[]{"Warhol", "Van Gogh", "Pollock", "Matisse"}, 0));
        questions.add(new Question("Who was the creator of the famous 'Campbell’s Soup Cans' artwork?", new String[]{"Warhol", "Lichtenstein", "Pollock", "Basquiat"}, 0));
        questions.add(new Question("Who painted 'The School of Athens'?", new String[]{"Raphael", "Da Vinci", "Michelangelo", "Titian"}, 0));
        questions.add(new Question("Which period is characterized by ornate details and dramatic use of light and shadow?", new String[]{"Baroque", "Renaissance", "Romanticism", "Impressionism"}, 0));
        questions.add(new Question("What is the medium used in encaustic painting?", new String[]{"Wax", "Oil", "Watercolor", "Acrylic"}, 0));
        questions.add(new Question("What was the focus of the Expressionist movement?", new String[]{"Portraying raw emotion", "Perfect realistic representation", "Color harmony", "Mathematical precision"}, 0));
        questions.add(new Question("Who was the artist behind the 'Fountain' sculpture, a urinal?", new String[]{"Duchamp", "Rodin", "Moore", "Calder"}, 0));
        questions.add(new Question("What is a fresco?", new String[]{"A painting on wet plaster", "A painting on canvas", "A digital artwork", "A wall sculpture"}, 0));
        questions.add(new Question("Which period of art is known for vivid colors, short brush strokes, and everyday life scenes?", new String[]{"Impressionism", "Surrealism", "Baroque", "Expressionism"}, 0));
        questions.add(new Question("Who is famous for the painting 'The Night Watch'?", new String[]{"Rembrandt", "Vermeer", "Rubens", "Van Gogh"}, 0));
        questions.add(new Question("What kind of materials are used in a 'collage'?", new String[]{"Paint", "Cut paper", "Metal", "Stone"}, 1));
        questions.add(new Question("Which artist was famous for abstract drip painting?", new String[]{"Pollock", "Mondrian", "Van Gogh", "Warhol"}, 0));
        questions.add(new Question("What does 'minimalism' focus on in art?", new String[]{"Color and texture", "Simplicity and form", "Realistic figures", "The unconscious mind"}, 1));
        questions.add(new Question("What is the term for a sculpture made from soft materials like clay?", new String[]{"Casting", "Modeling", "Carving", "Assembling"}, 1));
        questions.add(new Question("Who painted 'The Garden of Earthly Delights'?", new String[]{"Bosch", "Bruegel", "Dürer", "Raphael"}, 0));
        questions.add(new Question("Who was known for the use of light and shadow in Baroque art?", new String[]{"Caravaggio", "Vermeer", "Michelangelo", "Da Vinci"}, 0));
        questions.add(new Question("What is the purpose of a sketch in art?", new String[]{"To outline basic forms", "To color the entire scene", "To create a final piece", "To add detailed textures"}, 0));
        questions.add(new Question("Which ancient civilization is known for the development of sculpture and fresco art?", new String[]{"Greek", "Roman", "Egyptian", "Mesopotamian"}, 0));
        questions.add(new Question("What does 'abstract' art focus on?", new String[]{"Realistic depictions", "Geometric forms and colors", "Historical themes", "Natural landscapes"}, 1));

    }

    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
