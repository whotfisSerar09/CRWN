package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class bio extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(bio.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the basic unit of life?", new String[]{"Organ", "Tissue", "Cell", "Organism"}, 2));
        questions.add(new Question("What structure contains the genetic material in a cell?", new String[]{"Ribosome", "Nucleus", "Mitochondria", "Cytoplasm"}, 1));
        questions.add(new Question("Which organelle is known as the powerhouse of the cell?", new String[]{"Chloroplast", "Nucleus", "Endoplasmic reticulum", "Mitochondria"}, 3));
        questions.add(new Question("What molecule carries genetic information?", new String[]{"RNA", "DNA", "Protein", "Lipid"}, 1));
        questions.add(new Question("Which kingdom do humans belong to?", new String[]{"Plantae", "Fungi", "Animalia", "Protista"}, 2));
        questions.add(new Question("What type of blood cells fight infection?", new String[]{"Red", "White", "Platelets", "Plasma"}, 1));
        questions.add(new Question("What process do plants use to make food?", new String[]{"Respiration", "Digestion", "Photosynthesis", "Transpiration"}, 2));
        questions.add(new Question("Which gas is absorbed by plants during photosynthesis?", new String[]{"Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"}, 2));
        questions.add(new Question("Which macromolecule is made of amino acids?", new String[]{"Carbohydrate", "Lipid", "Protein", "Nucleic Acid"}, 2));
        questions.add(new Question("What is the process of cell division called?", new String[]{"Meiosis", "Fission", "Mitosis", "Budding"}, 2));
        questions.add(new Question("Which system controls the body's responses?", new String[]{"Digestive", "Circulatory", "Respiratory", "Nervous"}, 3));
        questions.add(new Question("What part of the brain controls balance?", new String[]{"Cerebrum", "Medulla", "Cerebellum", "Hypothalamus"}, 2));
        questions.add(new Question("Which organ filters blood in the human body?", new String[]{"Liver", "Heart", "Kidney", "Lungs"}, 2));
        questions.add(new Question("Which blood type is the universal donor?", new String[]{"A", "B", "AB", "O"}, 3));
        questions.add(new Question("Which vitamin is made when skin is exposed to sunlight?", new String[]{"Vitamin A", "Vitamin C", "Vitamin D", "Vitamin B12"}, 2));
        questions.add(new Question("What type of muscle is found in the heart?", new String[]{"Smooth", "Skeletal", "Cardiac", "Voluntary"}, 2));
        questions.add(new Question("What is the function of red blood cells?", new String[]{"Fight infection", "Help clot blood", "Transport oxygen", "Digest food"}, 2));
        questions.add(new Question("Which organ produces insulin?", new String[]{"Liver", "Pancreas", "Kidney", "Gallbladder"}, 1));
        questions.add(new Question("What is the largest organ in the human body?", new String[]{"Liver", "Heart", "Skin", "Lungs"}, 2));
        questions.add(new Question("Which molecule provides immediate energy?", new String[]{"DNA", "Fat", "Glucose", "Protein"}, 2));
        questions.add(new Question("Which process turns glucose into energy?", new String[]{"Photosynthesis", "Fermentation", "Cellular respiration", "Diffusion"}, 2));
        questions.add(new Question("What is the name of the pigment in red blood cells?", new String[]{"Chlorophyll", "Myoglobin", "Keratin", "Hemoglobin"}, 3));
        questions.add(new Question("What is a group of similar cells working together called?", new String[]{"Organ", "System", "Tissue", "Organism"}, 2));
        questions.add(new Question("Which human body system includes the skin?", new String[]{"Nervous", "Integumentary", "Muscular", "Lymphatic"}, 1));
        questions.add(new Question("Which structure allows gas exchange in the lungs?", new String[]{"Bronchi", "Alveoli", "Trachea", "Diaphragm"}, 1));
        questions.add(new Question("What is the primary function of the large intestine?", new String[]{"Absorb nutrients", "Produce enzymes", "Absorb water", "Digest fats"}, 2));
        questions.add(new Question("What is the female reproductive cell called?", new String[]{"Zygote", "Ovum", "Embryo", "Sperm"}, 1));
        questions.add(new Question("Which part of the plant absorbs water?", new String[]{"Leaves", "Stems", "Roots", "Flowers"}, 2));
        questions.add(new Question("What is the scientific name for humans?", new String[]{"Homo sapiens", "Pan troglodytes", "Canis lupus", "Felis catus"}, 0));
        questions.add(new Question("Which enzyme breaks down starch?", new String[]{"Lipase", "Pepsin", "Amylase", "Trypsin"}, 2));
        questions.add(new Question("Which blood vessels carry blood away from the heart?", new String[]{"Veins", "Arteries", "Capillaries", "Valves"}, 1));
        questions.add(new Question("Which part of a neuron receives signals?", new String[]{"Axon", "Dendrite", "Synapse", "Myelin"}, 1));
        questions.add(new Question("What is a mutation?", new String[]{"A virus", "A gene disorder", "A change in DNA", "A bacterial infection"}, 2));
        questions.add(new Question("Which type of cell lacks a nucleus?", new String[]{"Animal", "Plant", "Fungal", "Prokaryotic"}, 3));
        questions.add(new Question("What structure gives plants their green color?", new String[]{"Xylem", "Chloroplast", "Stomata", "Cell wall"}, 1));
        questions.add(new Question("Which organ system includes the brain and spinal cord?", new String[]{"Skeletal", "Muscular", "Endocrine", "Nervous"}, 3));
        questions.add(new Question("What is the study of heredity called?", new String[]{"Ecology", "Genetics", "Anatomy", "Taxonomy"}, 1));
        questions.add(new Question("What kind of symmetry does a human body have?", new String[]{"Radial", "Bilateral", "Asymmetrical", "Rotational"}, 1));
        questions.add(new Question("What are the building blocks of proteins?", new String[]{"Sugars", "Nucleotides", "Fatty acids", "Amino acids"}, 3));
        questions.add(new Question("Which blood component helps in clotting?", new String[]{"Red cells", "White cells", "Plasma", "Platelets"}, 3));
        questions.add(new Question("What is the role of the ribosome?", new String[]{"Make energy", "Store DNA", "Make proteins", "Transport water"}, 2));
        questions.add(new Question("What are genes made of?", new String[]{"Proteins", "Carbohydrates", "DNA", "Lipids"}, 2));
        questions.add(new Question("What is the function of xylem in plants?", new String[]{"Transport sugar", "Transport water", "Store nutrients", "Make seeds"}, 1));
        questions.add(new Question("Which body system controls hormones?", new String[]{"Lymphatic", "Endocrine", "Nervous", "Digestive"}, 1));
        questions.add(new Question("What is homeostasis?", new String[]{"Cell division", "Stable internal conditions", "Reproduction", "Digestion"}, 1));
        questions.add(new Question("Which organ is responsible for producing bile?", new String[]{"Pancreas", "Liver", "Stomach", "Gallbladder"}, 1));
        questions.add(new Question("What structure protects plant cells?", new String[]{"Membrane", "Nucleus", "Cell wall", "Cytoplasm"}, 2));
        questions.add(new Question("Which process creates sex cells?", new String[]{"Mitosis", "Binary fission", "Budding", "Meiosis"}, 3));
        questions.add(new Question("What is taxonomy?", new String[]{"Study of genes", "Study of tissues", "Classification of organisms", "Study of behavior"}, 2));
        questions.add(new Question("Which gas is a byproduct of photosynthesis?", new String[]{"Carbon dioxide", "Oxygen", "Nitrogen", "Methane"}, 1));
        questions.add(new Question("Which part of the plant is responsible for reproduction?", new String[]{"Leaf", "Root", "Stem", "Flower"}, 3));
        questions.add(new Question("Which part of the eye controls the amount of light entering?", new String[]{"Retina", "Cornea", "Lens", "Pupil"}, 3));
        questions.add(new Question("What type of reproduction involves one parent?", new String[]{"Sexual", "Binary", "Asexual", "Mitosis"}, 2));
        questions.add(new Question("Which animal is a vertebrate?", new String[]{"Jellyfish", "Starfish", "Frog", "Worm"}, 2));
        questions.add(new Question("What is the function of antibodies?", new String[]{"Digest food", "Fight infection", "Store energy", "Build cells"}, 1));
        questions.add(new Question("Which hormone regulates blood sugar?", new String[]{"Adrenaline", "Estrogen", "Insulin", "Melatonin"}, 2));
        questions.add(new Question("Which structure connects muscles to bones?", new String[]{"Ligament", "Cartilage", "Tendon", "Joint"}, 2));
        questions.add(new Question("What is an ecosystem?", new String[]{"Group of cells", "DNA pool", "Living and non-living interaction", "Only animals"}, 2));
        questions.add(new Question("Which blood cells carry oxygen?", new String[]{"White", "Red", "Platelets", "Plasma"}, 1));
        questions.add(new Question("What is the human body's normal temperature in Celsius?", new String[]{"35", "36.5", "37", "38"}, 2));
        questions.add(new Question("What is osmosis?", new String[]{"Movement of water", "Energy production", "Protein synthesis", "Oxygen absorption"}, 0));
        questions.add(new Question("What is a population in biology?", new String[]{"All species", "Group of same species", "Group of organs", "Group of cells"}, 1));
        questions.add(new Question("Where does digestion begin?", new String[]{"Stomach", "Mouth", "Esophagus", "Intestine"}, 1));
        questions.add(new Question("Which vitamin helps in blood clotting?", new String[]{"A", "B", "C", "K"}, 3));
        questions.add(new Question("What is the genetic makeup of an organism called?", new String[]{"Phenotype", "Genotype", "Trait", "Allele"}, 1));
        questions.add(new Question("Which organ removes carbon dioxide from the blood?", new String[]{"Heart", "Liver", "Lungs", "Kidneys"}, 2));
        questions.add(new Question("Which biome is characterized by very low temperatures?", new String[]{"Desert", "Tundra", "Rainforest", "Savanna"}, 1));
        questions.add(new Question("What is the smallest bone in the human body?", new String[]{"Femur", "Stapes", "Ulna", "Tibia"}, 1));
        questions.add(new Question("What are alleles?", new String[]{"Gene variants", "Hormones", "Enzymes", "Tissues"}, 0));
        questions.add(new Question("Which body system includes the heart and blood vessels?", new String[]{"Lymphatic", "Circulatory", "Endocrine", "Digestive"}, 1));
        questions.add(new Question("Which of the following is a lipid?", new String[]{"Starch", "Glucose", "Cholesterol", "Cellulose"}, 2));
        questions.add(new Question("What is the role of the small intestine?", new String[]{"Filter blood", "Absorb nutrients", "Store waste", "Produce bile"}, 1));
        questions.add(new Question("What is an autotroph?", new String[]{"Eats other organisms", "Makes its own food", "Only eats plants", "Only eats animals"}, 1));
        questions.add(new Question("Which organ regulates body temperature?", new String[]{"Liver", "Skin", "Heart", "Pancreas"}, 1));
        questions.add(new Question("What is the scientific study of animals?", new String[]{"Botany", "Zoology", "Ecology", "Genetics"}, 1));
        questions.add(new Question("Which structure controls what enters and exits the cell?", new String[]{"Nucleus", "Cytoplasm", "Cell membrane", "Cell wall"}, 2));
        questions.add(new Question("What is chlorophyll's role?", new String[]{"Store water", "Absorb sunlight", "Create proteins", "Transport oxygen"}, 1));
        questions.add(new Question("Which organ is responsible for hearing?", new String[]{"Nose", "Skin", "Eye", "Ear"}, 3));
        questions.add(new Question("What is the fluid portion of blood called?", new String[]{"Platelets", "Plasma", "Red cells", "White cells"}, 1));
        questions.add(new Question("What is the function of ligaments?", new String[]{"Attach muscle to bone", "Protect organs", "Store energy", "Connect bones"}, 3));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
