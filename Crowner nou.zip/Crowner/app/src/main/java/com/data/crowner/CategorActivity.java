package com.data.crowner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class CategorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_categor);

        // Geography
        Button btnGeography = findViewById(R.id.btnGeography);
        btnGeography.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, geo.class);
            startActivity(intent);
        });

        // History
        Button btnHistory = findViewById(R.id.btnHistory);
        btnHistory.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, history.class);
            startActivity(intent);
        });

        // Art
        Button btnArt = findViewById(R.id.btnArt);
        btnArt.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, art.class);
            startActivity(intent);
        });

        // Music
        Button btnMusic = findViewById(R.id.btnMusic);
        btnMusic.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, music.class);
            startActivity(intent);
        });

        // Astronomy
        Button btnAstronomy = findViewById(R.id.btnAstronomy);
        btnAstronomy.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, astro.class);
            startActivity(intent);
        });

        // Physics
        Button btnPhysics = findViewById(R.id.btnPhysics);
        btnPhysics.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, physics.class);
            startActivity(intent);
        });

        // Biology
        Button btnBiology = findViewById(R.id.btnBiology);
        btnBiology.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, bio.class);
            startActivity(intent);
        });

        // Chemistry
        Button btnChemistry = findViewById(R.id.btnChemistry);
        btnChemistry.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, chem.class);
            startActivity(intent);
        });

        // Math
        Button btnMath = findViewById(R.id.btnMath);
        btnMath.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, math.class);
            startActivity(intent);
        });

        // Literature
        Button btnLiterature = findViewById(R.id.btnLiterature);
        btnLiterature.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, litera.class);
            startActivity(intent);
        });

        // Back Button
        Button backButton = findViewById(R.id.button7);
        backButton.setOnClickListener(v -> {
            Intent intent = new Intent(CategorActivity.this, principal.class);
            startActivity(intent);
            finish();
        });
    }
}
