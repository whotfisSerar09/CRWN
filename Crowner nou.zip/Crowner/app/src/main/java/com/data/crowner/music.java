package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class music extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(music.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("Who is known as the King of Pop?", new String[]{"Michael Jackson", "Elvis Presley", "Prince", "Freddie Mercury"}, 0));
        questions.add(new Question("Which composer wrote the famous piece 'Eine kleine Nachtmusik'?", new String[]{"Mozart", "Beethoven", "Bach", "Chopin"}, 0));
        questions.add(new Question("What band is known for the hit song 'Bohemian Rhapsody'?", new String[]{"Queen", "The Beatles", "Led Zeppelin", "Pink Floyd"}, 0));
        questions.add(new Question("Which instrument does Yo-Yo Ma play?", new String[]{"Cello", "Violin", "Piano", "Guitar"}, 0));
        questions.add(new Question("What genre of music did the Beatles primarily play?", new String[]{"Rock", "Jazz", "Blues", "Classical"}, 0));
        questions.add(new Question("Which musical instrument has 88 keys?", new String[]{"Piano", "Violin", "Guitar", "Trumpet"}, 0));
        questions.add(new Question("Which song by Whitney Houston became a massive hit in the 1990s?", new String[]{"I Will Always Love You", "Greatest Love of All", "How Will I Know", "I Wanna Dance with Somebody"}, 0));
        questions.add(new Question("Who composed the famous 'Symphony No. 5'?", new String[]{"Beethoven", "Mozart", "Haydn", "Tchaikovsky"}, 0));
        questions.add(new Question("Which classical composer was deaf?", new String[]{"Beethoven", "Bach", "Chopin", "Mozart"}, 0));
        questions.add(new Question("What year did Elvis Presley pass away?", new String[]{"1977", "1980", "1967", "1990"}, 0));
        questions.add(new Question("What is the term for the speed of a piece of music?", new String[]{"Tempo", "Pitch", "Harmony", "Rhythm"}, 0));
        questions.add(new Question("Which popular musical is based on the life of a fictional teenage girl named Sandy?", new String[]{"Grease", "Cats", "Les Misérables", "The Phantom of the Opera"}, 0));
        questions.add(new Question("Which famous music festival took place in 1969?", new String[]{"Woodstock", "Coachella", "Lollapalooza", "Glastonbury"}, 0));
        questions.add(new Question("What genre of music is 'Strange Mercy' by St. Vincent?", new String[]{"Indie Rock", "Pop", "Classical", "Jazz"}, 0));
        questions.add(new Question("What is the highest male vocal range?", new String[]{"Tenor", "Bass", "Baritone", "Alto"}, 0));
        questions.add(new Question("Which artist released the album 'Lemonade'?", new String[]{"Beyoncé", "Rihanna", "Ariana Grande", "Nicki Minaj"}, 0));
        questions.add(new Question("What type of musical ensemble is an orchestra?", new String[]{"Large ensemble", "Small group", "Solo performance", "Band"}, 0));
        questions.add(new Question("What is the term for a group of musicians performing together?", new String[]{"Band", "Soloist", "Duo", "Orchestra"}, 0));
        questions.add(new Question("What is the name of the famous music awards ceremony held annually?", new String[]{"The Grammys", "The Oscars", "The Tonys", "The Emmys"}, 0));
        questions.add(new Question("Who is known for the hit song 'Like a Rolling Stone'?", new String[]{"Bob Dylan", "Johnny Cash", "Bruce Springsteen", "Neil Young"}, 0));
        questions.add(new Question("Which musical instrument is played with a bow?", new String[]{"Violin", "Flute", "Piano", "Guitar"}, 0));
        questions.add(new Question("Which song by the Rolling Stones was released in 1965?", new String[]{"(I Can't Get No) Satisfaction", "Paint It Black", "Angie", "Start Me Up"}, 0));
        questions.add(new Question("Who composed 'The Four Seasons'?", new String[]{"Vivaldi", "Bach", "Beethoven", "Mozart"}, 0));
        questions.add(new Question("Which music genre is characterized by its use of electronic instruments and heavy bass?", new String[]{"Dubstep", "Classical", "Jazz", "Pop"}, 0));
        questions.add(new Question("Who is the lead singer of the band U2?", new String[]{"Bono", "Mick Jagger", "Freddie Mercury", "Bruce Springsteen"}, 0));
        questions.add(new Question("What is the name of Adele's debut album?", new String[]{"19", "21", "25", "30"}, 0));
        questions.add(new Question("What is the term for the distance between two notes in music?", new String[]{"Interval", "Scale", "Chord", "Tempo"}, 0));
        questions.add(new Question("What is the first note in the solfège scale?", new String[]{"Do", "Re", "Mi", "Fa"}, 0));
        questions.add(new Question("Who wrote the musical 'The Phantom of the Opera'?", new String[]{"Andrew Lloyd Webber", "Stephen Sondheim", "Lin-Manuel Miranda", "George Gershwin"}, 0));
        questions.add(new Question("Which rock band is known for the album 'Dark Side of the Moon'?", new String[]{"Pink Floyd", "Led Zeppelin", "The Beatles", "The Who"}, 0));
        questions.add(new Question("Which famous pop singer released the album 'Thriller'?", new String[]{"Michael Jackson", "Elvis Presley", "Prince", "Madonna"}, 0));
        questions.add(new Question("What is the name of the famous rock festival held every year in the UK?", new String[]{"Glastonbury", "Coachella", "Woodstock", "Lollapalooza"}, 0));
        questions.add(new Question("What is the term for a repeated section of a song?", new String[]{"Refrain", "Verse", "Bridge", "Chorus"}, 0));
        questions.add(new Question("Which popular music genre originated in Jamaica?", new String[]{"Reggae", "Jazz", "Blues", "Rock 'n' Roll"}, 0));
        questions.add(new Question("What is the highest female vocal range?", new String[]{"Soprano", "Alto", "Tenor", "Baritone"}, 0));
        questions.add(new Question("Who is known for the hit song 'Poker Face'?", new String[]{"Lady Gaga", "Katy Perry", "Beyoncé", "Rihanna"}, 0));
        questions.add(new Question("Which band is famous for the song 'Stairway to Heaven'?", new String[]{"Led Zeppelin", "The Doors", "The Rolling Stones", "Pink Floyd"}, 0));
        questions.add(new Question("What is the title of Elton John's famous song about a rocket man?", new String[]{"Rocket Man", "Tiny Dancer", "Your Song", "Bennie and the Jets"}, 0));
        questions.add(new Question("Who is the composer of 'Für Elise'?", new String[]{"Beethoven", "Mozart", "Chopin", "Bach"}, 0));
        questions.add(new Question("Which composer is known for his 'Eine kleine Nachtmusik'?", new String[]{"Mozart", "Beethoven", "Bach", "Schubert"}, 0));
        questions.add(new Question("What musical scale has no sharps or flats?", new String[]{"C Major", "A Minor", "D Major", "F Major"}, 0));
        questions.add(new Question("Which famous music icon was known as the 'Queen of Soul'?", new String[]{"Aretha Franklin", "Beyoncé", "Whitney Houston", "Tina Turner"}, 0));
        questions.add(new Question("Which song did The Beatles famously sing in 1963 that became a worldwide hit?", new String[]{"I Want to Hold Your Hand", "Hey Jude", "Let It Be", "Yesterday"}, 0));
        questions.add(new Question("What is the term for a collection of musical works released together?", new String[]{"Album", "Single", "Track", "Playlist"}, 0));
        questions.add(new Question("What famous music venue is located in New York City?", new String[]{"Carnegie Hall", "Madison Square Garden", "Royal Albert Hall", "The Ryman Auditorium"}, 0));
        questions.add(new Question("Who was the first female artist to win the Grammy Award for Album of the Year?", new String[]{"Barbra Streisand", "Aretha Franklin", "Beyoncé", "Adele"}, 0));
        questions.add(new Question("What is the term for the speed of a piece of music?", new String[]{"Tempo", "Pitch", "Key", "Chord"}, 0));
        questions.add(new Question("Who is the creator of the musical 'Hamilton'?", new String[]{"Lin-Manuel Miranda", "Stephen Sondheim", "Andrew Lloyd Webber", "Jonathan Larson"}, 0));
        questions.add(new Question("Which music video is known for its iconic 'moonwalk' dance move?", new String[]{"Billie Jean", "Thriller", "Beat It", "Smooth Criminal"}, 0));
        questions.add(new Question("What is the term for the ability to sing in tune?", new String[]{"Pitch", "Tone", "Harmony", "Rhythm"}, 0));
        questions.add(new Question("What is the name of Beyoncé's debut album?", new String[]{"Dangerously in Love", "B'Day", "4", "Lemonade"}, 0));
        questions.add(new Question("Which classical composer wrote 'The Magic Flute'?", new String[]{"Mozart", "Bach", "Beethoven", "Schubert"}, 0));
        questions.add(new Question("What is the name of Michael Jackson's famous pet chimpanzee?", new String[]{"Bubbles", "Coco", "Charlie", "Jack"}, 0));
        questions.add(new Question("What term describes the 'highness' or 'lowness' of a musical note?", new String[]{"Pitch", "Tone", "Key", "Tempo"}, 0));
        questions.add(new Question("Who composed 'Clair de Lune'?", new String[]{"Claude Debussy", "Ludwig van Beethoven", "Johann Sebastian Bach", "Frédéric Chopin"}, 0));
        questions.add(new Question("Which famous band was originally known as 'The Quarrymen'?", new String[]{"The Beatles", "The Rolling Stones", "The Who", "Pink Floyd"}, 0));
        questions.add(new Question("Which instrument does Miles Davis play?", new String[]{"Trumpet", "Saxophone", "Piano", "Guitar"}, 0));
        questions.add(new Question("What is the term for a group of three musicians?", new String[]{"Trio", "Duo", "Quartet", "Quintet"}, 0));
        questions.add(new Question("What is the name of the famous classical composer who had a famous 'requiem'?", new String[]{"Mozart", "Bach", "Beethoven", "Chopin"}, 0));
        questions.add(new Question("What type of music features a repetitive beat and was made popular by DJs?", new String[]{"Electronic Dance Music", "Jazz", "Pop", "Classical"}, 0));
        questions.add(new Question("What genre of music does the band Nirvana belong to?", new String[]{"Grunge", "Rock", "Pop", "Jazz"}, 0));
        questions.add(new Question("Which of the following artists is known for the song 'Rolling in the Deep'?", new String[]{"Adele", "Taylor Swift", "Rihanna", "Beyoncé"}, 0));
        questions.add(new Question("Which famous pop star is known for the song 'Toxic'?", new String[]{"Britney Spears", "Katy Perry", "Lady Gaga", "Ariana Grande"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
