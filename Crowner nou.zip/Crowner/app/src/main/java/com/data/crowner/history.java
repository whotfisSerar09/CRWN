package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class history extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(history.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("Who was the first president of the United States?", new String[]{"George Washington", "Thomas Jefferson", "Abraham Lincoln", "John Adams"}, 0));
        questions.add(new Question("Which year did World War I begin?", new String[]{"1914", "1939", "1912", "1918"}, 0));
        questions.add(new Question("Who was the first emperor of China?", new String[]{"Qin Shi Huang", "Kublai Khan", "Emperor Wu", "Li Shimin"}, 0));
        questions.add(new Question("What was the name of the ship that brought the Pilgrims to America in 1620?", new String[]{"Mayflower", "Santa Maria", "Titanic", "Endurance"}, 0));
        questions.add(new Question("Who was the British prime minister during World War II?", new String[]{"Winston Churchill", "Neville Chamberlain", "Clement Attlee", "Harold Macmillan"}, 0));
        questions.add(new Question("What ancient civilization built the pyramids of Giza?", new String[]{"Ancient Egypt", "Mesopotamia", "Ancient Greece", "Roman Empire"}, 0));
        questions.add(new Question("Who was the first woman to fly solo across the Atlantic Ocean?", new String[]{"Amelia Earhart", "Bessie Coleman", "Harriet Quimby", "Rosie the Riveter"}, 0));
        questions.add(new Question("Which event marked the start of the American Civil War?", new String[]{"Attack on Fort Sumter", "Battle of Gettysburg", "Emancipation Proclamation", "Signing of the Declaration of Independence"}, 0));
        questions.add(new Question("What was the main cause of the French Revolution?", new String[]{"Economic inequality", "Napoleon's expansion", "The Industrial Revolution", "Religious conflict"}, 0));
        questions.add(new Question("Who was the last pharaoh of ancient Egypt?", new String[]{"Cleopatra", "Nefertiti", "Hatshepsut", "Ramses II"}, 0));
        questions.add(new Question("Which empire was ruled by Julius Caesar?", new String[]{"Roman Empire", "Ottoman Empire", "Byzantine Empire", "Mongol Empire"}, 0));
        questions.add(new Question("Which war was fought between the North and South of the United States?", new String[]{"American Civil War", "World War I", "Spanish-American War", "War of 1812"}, 0));
        questions.add(new Question("Who was the leader of the Soviet Union during World War II?", new String[]{"Joseph Stalin", "Vladimir Lenin", "Leon Trotsky", "Mikhail Gorbachev"}, 0));
        questions.add(new Question("What year did the Berlin Wall fall?", new String[]{"1989", "1991", "1975", "1963"}, 0));
        questions.add(new Question("Who was the first king of England?", new String[]{"Æthelstan", "William the Conqueror", "Henry VIII", "Alfred the Great"}, 0));
        questions.add(new Question("Which battle was Napoleon Bonaparte's final defeat?", new String[]{"Battle of Waterloo", "Battle of Leipzig", "Battle of Trafalgar", "Battle of Austerlitz"}, 0));
        questions.add(new Question("Who discovered the Americas in 1492?", new String[]{"Christopher Columbus", "Vasco da Gama", "Marco Polo", "Ferdinand Magellan"}, 0));
        questions.add(new Question("Which war was fought between 1914 and 1918?", new String[]{"World War I", "World War II", "Korean War", "Vietnam War"}, 0));
        questions.add(new Question("Who was the leader of Nazi Germany during World War II?", new String[]{"Adolf Hitler", "Joseph Stalin", "Benito Mussolini", "Hirohito"}, 0));
        questions.add(new Question("What year did the Titanic sink?", new String[]{"1912", "1905", "1898", "1920"}, 0));
        questions.add(new Question("Which civilization is known for creating the first written code of law?", new String[]{"Babylonians", "Romans", "Greeks", "Egyptians"}, 0));
        questions.add(new Question("What was the name of the ship that carried the first English settlers to Jamestown?", new String[]{"Susan Constant", "Mayflower", "Santa Maria", "Endeavour"}, 0));
        questions.add(new Question("Who was the leader of the Indian independence movement?", new String[]{"Mahatma Gandhi", "Jawaharlal Nehru", "Subhas Chandra Bose", "Indira Gandhi"}, 0));
        questions.add(new Question("Which war ended with the Treaty of Versailles?", new String[]{"World War I", "World War II", "Korean War", "American Civil War"}, 0));
        questions.add(new Question("Which civilization built the Machu Picchu?", new String[]{"Inca", "Aztec", "Maya", "Olmec"}, 0));
        questions.add(new Question("Which explorer first sailed around the world?", new String[]{"Ferdinand Magellan", "Christopher Columbus", "Marco Polo", "Vasco da Gama"}, 0));
        questions.add(new Question("What year did the United States declare independence?", new String[]{"1776", "1492", "1812", "1607"}, 0));
        questions.add(new Question("What was the main reason for the American Revolution?", new String[]{"Taxation without representation", "Slavery", "Religious freedom", "Territorial disputes"}, 0));
        questions.add(new Question("Who was the leader of the Bolshevik Revolution?", new String[]{"Vladimir Lenin", "Joseph Stalin", "Leon Trotsky", "Nikita Khrushchev"}, 0));
        questions.add(new Question("Who was the first emperor of Japan?", new String[]{"Emperor Jimmu", "Emperor Hirohito", "Emperor Akihito", "Emperor Meiji"}, 0));
        questions.add(new Question("Which event marked the beginning of World War II?", new String[]{"Invasion of Poland", "Pearl Harbor attack", "Hitler's invasion of France", "Attack on Pearl Harbor"}, 0));
        questions.add(new Question("Which country was formerly known as Persia?", new String[]{"Iran", "Iraq", "Turkey", "Afghanistan"}, 0));
        questions.add(new Question("Who was the first man to step on the moon?", new String[]{"Neil Armstrong", "Buzz Aldrin", "Yuri Gagarin", "Michael Collins"}, 0));
        questions.add(new Question("Which country did the United States fight in the Vietnam War?", new String[]{"North Vietnam", "South Vietnam", "China", "Japan"}, 0));
        questions.add(new Question("What was the name of the ship that the Pilgrims sailed on to America in 1620?", new String[]{"Mayflower", "Pinta", "Santa Maria", "Endurance"}, 0));
        questions.add(new Question("Who wrote the Communist Manifesto?", new String[]{"Karl Marx", "Vladimir Lenin", "Friedrich Engels", "Leon Trotsky"}, 0));
        questions.add(new Question("Which Roman emperor famously said, 'I came, I saw, I conquered'?", new String[]{"Julius Caesar", "Augustus", "Nero", "Caligula"}, 0));
        questions.add(new Question("What was the name of the first artificial satellite launched into space?", new String[]{"Sputnik", "Explorer 1", "Apollo 11", "Vanguard 1"}, 0));
        questions.add(new Question("Who was the first woman to serve as prime minister of the United Kingdom?", new String[]{"Margaret Thatcher", "Queen Elizabeth I", "Theresa May", "Emmeline Pankhurst"}, 0));
        questions.add(new Question("Which was the first country to grant women the right to vote?", new String[]{"New Zealand", "United States", "Sweden", "France"}, 0));
        questions.add(new Question("Which war was fought between the United States and Mexico in the mid-1800s?", new String[]{"Mexican-American War", "War of 1812", "Civil War", "Spanish-American War"}, 0));
        questions.add(new Question("Who was the leader of the Confederate States during the American Civil War?", new String[]{"Jefferson Davis", "Abraham Lincoln", "Robert E. Lee", "Stonewall Jackson"}, 0));
        questions.add(new Question("Which was the first country to develop nuclear weapons?", new String[]{"United States", "Soviet Union", "Germany", "United Kingdom"}, 0));
        questions.add(new Question("Which empire was known for its gladiatorial contests?", new String[]{"Roman Empire", "Ottoman Empire", "Mongol Empire", "Byzantine Empire"}, 0));
        questions.add(new Question("Who was the last Tsar of Russia?", new String[]{"Nicholas II", "Peter the Great", "Catherine the Great", "Alexander III"}, 0));
        questions.add(new Question("Which battle was fought on June 6, 1944, during World War II?", new String[]{"D-Day", "Battle of the Bulge", "Battle of Stalingrad", "Pearl Harbor attack"}, 0));
        questions.add(new Question("Which war ended with the signing of the Treaty of Paris in 1783?", new String[]{"American Revolution", "War of 1812", "Civil War", "Spanish-American War"}, 0));
        questions.add(new Question("What was the name of the ship that brought the first English settlers to Jamestown in 1607?", new String[]{"Susan Constant", "Mayflower", "Santa Maria", "Endeavour"}, 0));
        questions.add(new Question("Who was the leader of the Mongol Empire?", new String[]{"Genghis Khan", "Kublai Khan", "Alexander the Great", "Cyrus the Great"}, 0));
        questions.add(new Question("Which president abolished slavery in the United States?", new String[]{"Abraham Lincoln", "George Washington", "Thomas Jefferson", "Andrew Johnson"}, 0));
        questions.add(new Question("Which event led to the United States entering World War I?", new String[]{"Sinking of the Lusitania", "Pearl Harbor attack", "Zimmermann Telegram", "Russian Revolution"}, 0));
        questions.add(new Question("Who was the first leader of the Soviet Union?", new String[]{"Vladimir Lenin", "Joseph Stalin", "Leon Trotsky", "Nikita Khrushchev"}, 0));
        questions.add(new Question("What year did the American Civil War end?", new String[]{"1865", "1861", "1776", "1812"}, 0));
        questions.add(new Question("Which ancient civilization is known for the hanging gardens of Babylon?", new String[]{"Babylonia", "Sumeria", "Assyria", "Egypt"}, 0));
        questions.add(new Question("Who was the famous queen of ancient Egypt?", new String[]{"Cleopatra", "Nefertiti", "Hatshepsut", "Maat"}, 0));
        questions.add(new Question("Which empire controlled most of Europe during the early 20th century?", new String[]{"Austro-Hungarian Empire", "Ottoman Empire", "Roman Empire", "Russian Empire"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}