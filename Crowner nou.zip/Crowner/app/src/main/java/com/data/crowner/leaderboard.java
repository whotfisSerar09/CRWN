package com.data.crowner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Scanner;

public class leaderboard extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboard); // Links this Activity to a layout file

        Button btnbbb;
        btnbbb = findViewById(R.id.button9);

        btnbbb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent I = new Intent(leaderboard.this, principal.class);
                startActivity(I);
            }
        });
    }


}