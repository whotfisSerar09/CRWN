package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class math extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(math.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the value of pi to two decimal places?", new String[]{"3.14", "3.15", "3.12", "3.10"}, 0));
        questions.add(new Question("What is the sum of the angles in a triangle?", new String[]{"180 degrees", "90 degrees", "360 degrees", "270 degrees"}, 0));
        questions.add(new Question("What is the square root of 64?", new String[]{"8", "6", "10", "16"}, 0));
        questions.add(new Question("What is the result of 7 + 8?", new String[]{"15", "14", "16", "17"}, 0));
        questions.add(new Question("What is the value of 9 squared?", new String[]{"81", "72", "90", "99"}, 0));
        questions.add(new Question("What is the derivative of x^2?", new String[]{"2x", "x^2", "2", "x"}, 0));
        questions.add(new Question("Which of the following is a prime number?", new String[]{"7", "9", "8", "4"}, 0));
        questions.add(new Question("What is the value of 5 factorial (5!)?", new String[]{"120", "100", "60", "24"}, 0));
        questions.add(new Question("What is the perimeter of a square with side length 4?", new String[]{"16", "12", "8", "20"}, 0));
        questions.add(new Question("What is the area of a circle with radius 3?", new String[]{"28.27", "15.71", "9.42", "10.24"}, 0));
        questions.add(new Question("What is the value of the square root of 49?", new String[]{"7", "8", "6", "9"}, 0));
        questions.add(new Question("What is the slope of the line 2x + 3y = 6?", new String[]{"-2/3", "2/3", "3/2", "-3/2"}, 0));
        questions.add(new Question("What is the sum of the angles in a quadrilateral?", new String[]{"360 degrees", "180 degrees", "90 degrees", "270 degrees"}, 0));
        questions.add(new Question("What is 15% of 200?", new String[]{"30", "25", "20", "15"}, 0));
        questions.add(new Question("What is the volume of a cube with side length 3?", new String[]{"27", "9", "18", "12"}, 0));
        questions.add(new Question("What is the derivative of sin(x)?", new String[]{"cos(x)", "sin(x)", "-cos(x)", "-sin(x)"}, 0));
        questions.add(new Question("What is 2 to the power of 3?", new String[]{"8", "6", "4", "2"}, 0));
        questions.add(new Question("What is the circumference of a circle with radius 5?", new String[]{"31.42", "25.13", "18.84", "15.70"}, 0));
        questions.add(new Question("What is the value of x if 2x = 10?", new String[]{"5", "3", "2", "4"}, 0));
        questions.add(new Question("What is the result of 12 divided by 4?", new String[]{"3", "2", "4", "6"}, 0));
        questions.add(new Question("What is the volume of a sphere with radius 2?", new String[]{"33.51", "50.24", "12.57", "10.47"}, 0));
        questions.add(new Question("What is the area of a right triangle with base 4 and height 5?", new String[]{"10", "20", "15", "25"}, 0));
        questions.add(new Question("What is the sum of the interior angles of a hexagon?", new String[]{"720 degrees", "540 degrees", "360 degrees", "180 degrees"}, 0));
        questions.add(new Question("What is the value of 2x + 3 when x = 4?", new String[]{"11", "10", "12", "13"}, 0));
        questions.add(new Question("What is the cosine of 0 degrees?", new String[]{"1", "0", "-1", "undefined"}, 0));
        questions.add(new Question("What is the product of 6 and 7?", new String[]{"42", "40", "38", "45"}, 0));
        questions.add(new Question("What is the result of 25 divided by 5?", new String[]{"5", "6", "4", "3"}, 0));
        questions.add(new Question("What is the area of a rectangle with length 5 and width 8?", new String[]{"40", "45", "30", "35"}, 0));
        questions.add(new Question("What is the hypotenuse of a right triangle with legs of 3 and 4?", new String[]{"5", "6", "7", "8"}, 0));
        questions.add(new Question("What is the sum of 100 and 200?", new String[]{"300", "250", "350", "400"}, 0));
        questions.add(new Question("What is the quotient of 81 divided by 9?", new String[]{"9", "8", "7", "10"}, 0));
        questions.add(new Question("What is the derivative of cos(x)?", new String[]{"-sin(x)", "sin(x)", "-cos(x)", "cos(x)"}, 0));
        questions.add(new Question("What is the value of 10 to the power of 2?", new String[]{"100", "10", "20", "50"}, 0));
        questions.add(new Question("What is the result of 3x - 4 = 5 when x = 3?", new String[]{"5", "9", "7", "10"}, 0));
        questions.add(new Question("What is the area of a triangle with base 6 and height 8?", new String[]{"24", "36", "16", "48"}, 0));
        questions.add(new Question("What is 7 times 8?", new String[]{"56", "49", "63", "48"}, 0));
        questions.add(new Question("What is the square of 12?", new String[]{"144", "132", "121", "100"}, 0));
        questions.add(new Question("What is the solution to the equation x + 5 = 12?", new String[]{"7", "5", "17", "10"}, 0));
        questions.add(new Question("What is the value of 6 to the power of 2?", new String[]{"36", "24", "48", "72"}, 0));
        questions.add(new Question("What is the perimeter of a rectangle with length 6 and width 4?", new String[]{"20", "24", "18", "16"}, 0));
        questions.add(new Question("What is the sum of 4, 7, and 9?", new String[]{"20", "21", "19", "22"}, 0));
        questions.add(new Question("What is the square root of 100?", new String[]{"10", "12", "8", "14"}, 0));
        questions.add(new Question("What is the value of the tangent of 45 degrees?", new String[]{"1", "0", "-1", "undefined"}, 0));
        questions.add(new Question("What is 15 times 6?", new String[]{"90", "80", "100", "95"}, 0));
        questions.add(new Question("What is the value of x in the equation 3x + 4 = 10?", new String[]{"2", "3", "4", "1"}, 0));
        questions.add(new Question("What is the area of a square with side length 7?", new String[]{"49", "42", "56", "63"}, 0));
        questions.add(new Question("What is the perimeter of a triangle with sides of length 5, 12, and 13?", new String[]{"30", "28", "26", "32"}, 0));
        questions.add(new Question("What is the value of 10 + 2 * 3?", new String[]{"16", "18", "20", "14"}, 0));
        questions.add(new Question("What is the sum of 13, 19, and 22?", new String[]{"54", "52", "56", "50"}, 0));
        questions.add(new Question("What is the sum of 3 + 4 + 5?", new String[]{"12", "13", "11", "10"}, 0));
        questions.add(new Question("What is the value of x in the equation 4x - 5 = 19?", new String[]{"6", "7", "5", "8"}, 0));
        questions.add(new Question("What is the derivative of e^x?", new String[]{"e^x", "x", "1", "e"}, 0));
        questions.add(new Question("What is the value of 20% of 50?", new String[]{"10", "12", "15", "5"}, 0));
        questions.add(new Question("What is the solution to the equation x/3 = 9?", new String[]{"27", "3", "18", "12"}, 0));
        questions.add(new Question("What is the cosine of 90 degrees?", new String[]{"0", "1", "-1", "undefined"}, 0));
        questions.add(new Question("What is the volume of a cone with radius 4 and height 9?", new String[]{"113.1", "120.0", "100.5", "110.5"}, 0));
        questions.add(new Question("What is the value of 4 to the power of 3?", new String[]{"64", "24", "32", "48"}, 0));
        questions.add(new Question("What is the sum of the first five prime numbers?", new String[]{"28", "29", "30", "31"}, 0));
        questions.add(new Question("What is the area of a circle with radius 6?", new String[]{"113.1", "100.5", "113.6", "120.0"}, 0));
        questions.add(new Question("What is the value of the derivative of x^3?", new String[]{"3x^2", "2x", "x^3", "x^2"}, 0));
        questions.add(new Question("What is the volume of a cube with side length 4?", new String[]{"64", "48", "32", "36"}, 0));
        questions.add(new Question("What is the value of the tangent of 30 degrees?", new String[]{"√3/3", "1", "√2", "0"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
