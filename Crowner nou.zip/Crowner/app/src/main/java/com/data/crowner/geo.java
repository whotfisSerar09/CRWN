package com.data.crowner;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;  // Import ProgressBar
import android.widget.TextView;
import android.widget.Toast;
import android.media.MediaPlayer;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class geo extends AppCompatActivity {

    private TextView questionText, resultText, crownText, questionNumberText;
    private Button answerButton1, answerButton2, answerButton3, answerButton4;
    private ProgressBar progressBar;  // Declare ProgressBar

    private int currentQuestionIndex = 0;
    private int crownPoints = 0;  // Track crown points
    private List<Question> questions = new ArrayList<>();
    private List<Question> selectedQuestions = new ArrayList<>();

    private MediaPlayer mediaPlayer; // Declare MediaPlayer outside the method to handle global sound control

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_questions);

        // Initialize views
        questionText = findViewById(R.id.questionText);
        resultText = findViewById(R.id.resultText);
        crownText = findViewById(R.id.crownText);  // TextView to display crown points
        questionNumberText = findViewById(R.id.questionNumberText);  // TextView to display current question number
        answerButton1 = findViewById(R.id.answerButton1);
        answerButton2 = findViewById(R.id.answerButton2);
        answerButton3 = findViewById(R.id.answerButton3);
        answerButton4 = findViewById(R.id.answerButton4);
        progressBar = findViewById(R.id.progressBar);  // Initialize the ProgressBar

        // Create 30 questions
        createQuestions();

        // Randomly shuffle the list of questions and select the first 10
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        Collections.shuffle(questions);
        selectedQuestions.clear();
        selectedQuestions.addAll(questions.subList(0, 10));

        // Set the first question
        loadQuestion(currentQuestionIndex);

        // Set answer buttons onClick listeners
        answerButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(0);
            }
        });
        answerButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(1);
            }
        });
        answerButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(2);
            }
        });
        answerButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer(3);
            }
        });
    }

    private void loadQuestion(int index) {
        if (index >= selectedQuestions.size()) {
            // Quiz finished, move to final screen
            Intent intent = new Intent(geo.this, score.class);
            intent.putExtra("finalScore", crownPoints); // Pass the score
            startActivity(intent);
            finish(); // Close MainActivity
            return;
        }

        Question currentQuestion = selectedQuestions.get(index);
        questionText.setText(currentQuestion.getQuestion());

        // Shuffle the answers and set the answer buttons
        String[] shuffledAnswers = currentQuestion.getShuffledAnswers();
        answerButton1.setText(shuffledAnswers[0]);
        answerButton2.setText(shuffledAnswers[1]);
        answerButton3.setText(shuffledAnswers[2]);
        answerButton4.setText(shuffledAnswers[3]);

        resultText.setText("");

        // Update the question number text (1/10, 2/10, etc.)
        questionNumberText.setText("Question: " + (index + 1) + "/10");

        // Update the progress bar
        int progress = (int) (((float) (index + 1) / selectedQuestions.size()) * 100); // Calculate progress
        progressBar.setProgress(progress);
    }

    private void checkAnswer(int answerIndex) {
        Question currentQuestion = selectedQuestions.get(currentQuestionIndex);
        Button selectedButton = null;

        // Manage button selection based on the answerIndex
        if (answerIndex == 0) {
            selectedButton = answerButton1;
        } else if (answerIndex == 1) {
            selectedButton = answerButton2;
        } else if (answerIndex == 2) {
            selectedButton = answerButton3;
        } else if (answerIndex == 3) {
            selectedButton = answerButton4;
        }

        // If the selected button is not null, proceed
        if (selectedButton != null) {
            // Stop the previous sound if it's playing
            if (mediaPlayer != null) {
                mediaPlayer.stop();  // Stop the current sound
                mediaPlayer.release();  // Release resources
            }

            // Check if the answer is correct
            if (answerIndex == currentQuestion.getCorrectAnswerIndex()) {
                crownPoints += 10;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Correct!");

                // Play correct answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.correct);
                mediaPlayer.start();  // Play the sound

                // Flash the button green
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_green_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                crownPoints -= 5;
                crownText.setText("Crown Points: " + crownPoints);
                resultText.setText("Try again!");

                // Play wrong answer sound
                mediaPlayer = MediaPlayer.create(this, R.raw.wrong);
                mediaPlayer.start();  // Play the sound

                // Flash the button red
                selectedButton.setBackgroundColor(getResources().getColor(android.R.color.holo_red_light));

                // Reset the button color after 500ms
                final Button buttonToReset = selectedButton;
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        buttonToReset.setBackgroundColor(Color.parseColor("#D3BE13"));
                    }
                }, 500);

                Toast.makeText(this, "Incorrect! You lost 5 crowns. Try again.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void disableButtons() {
        answerButton1.setEnabled(false);
        answerButton2.setEnabled(false);
        answerButton3.setEnabled(false);
        answerButton4.setEnabled(false);
    }

    // Method to create 30 questions
    private void createQuestions() {
        questions.add(new Question("What is the capital city of France?", new String[]{"Paris", "London", "Berlin", "Rome"}, 0));
        questions.add(new Question("Which country has the largest land area?", new String[]{"Russia", "Canada", "United States", "China"}, 0));
        questions.add(new Question("What is the longest river in the world?", new String[]{"Nile", "Amazon", "Yangtze", "Mississippi"}, 0));
        questions.add(new Question("Which continent is known as the 'Dark Continent'?", new String[]{"Africa", "Asia", "South America", "Australia"}, 0));
        questions.add(new Question("Which ocean is the largest?", new String[]{"Pacific Ocean", "Atlantic Ocean", "Indian Ocean", "Arctic Ocean"}, 0));
        questions.add(new Question("Which country is home to the Great Barrier Reef?", new String[]{"Australia", "United States", "South Africa", "India"}, 0));
        questions.add(new Question("Which mountain is the tallest in the world?", new String[]{"Mount Everest", "K2", "Kangchenjunga", "Makalu"}, 0));
        questions.add(new Question("Which country has the most volcanoes?", new String[]{"Indonesia", "Japan", "United States", "Italy"}, 0));
        questions.add(new Question("What is the capital city of Japan?", new String[]{"Tokyo", "Seoul", "Beijing", "Bangkok"}, 0));
        questions.add(new Question("Which desert is the largest in the world?", new String[]{"Sahara", "Karakum", "Gobi", "Atacama"}, 0));
        questions.add(new Question("Which city is the capital of the United States?", new String[]{"Washington, D.C.", "New York", "Los Angeles", "Chicago"}, 0));
        questions.add(new Question("Which river flows through Egypt?", new String[]{"Nile", "Amazon", "Ganges", "Yangtze"}, 0));
        questions.add(new Question("Which country is known for the Pyramids of Giza?", new String[]{"Egypt", "Mexico", "Peru", "Greece"}, 0));
        questions.add(new Question("What is the longest mountain range in the world?", new String[]{"Andes", "Himalayas", "Rockies", "Alps"}, 0));
        questions.add(new Question("Which continent is the Sahara Desert located on?", new String[]{"Africa", "Asia", "Australia", "Europe"}, 0));
        questions.add(new Question("Which country has the most islands?", new String[]{"Sweden", "Finland", "Canada", "Indonesia"}, 0));
        questions.add(new Question("What is the largest country in Africa?", new String[]{"Algeria", "Nigeria", "South Africa", "Egypt"}, 0));
        questions.add(new Question("What is the capital city of Brazil?", new String[]{"Brasília", "Rio de Janeiro", "São Paulo", "Buenos Aires"}, 0));
        questions.add(new Question("Which is the smallest country in the world by area?", new String[]{"Vatican City", "Monaco", "San Marino", "Liechtenstein"}, 0));
        questions.add(new Question("Which mountain range forms the natural border between France and Spain?", new String[]{"Pyrenees", "Alps", "Andes", "Rockies"}, 0));
        questions.add(new Question("Which country is the island of Bali a part of?", new String[]{"Indonesia", "Thailand", "Philippines", "Malaysia"}, 0));
        questions.add(new Question("Which country is the Great Wall of China located in?", new String[]{"China", "India", "Russia", "Japan"}, 0));
        questions.add(new Question("Which city is the capital of Canada?", new String[]{"Ottawa", "Toronto", "Vancouver", "Montreal"}, 0));
        questions.add(new Question("Which river is the longest in the United States?", new String[]{"Missouri River", "Mississippi River", "Colorado River", "Rio Grande"}, 0));
        questions.add(new Question("What is the capital city of Australia?", new String[]{"Canberra", "Sydney", "Melbourne", "Brisbane"}, 0));
        questions.add(new Question("What is the smallest continent by land area?", new String[]{"Australia", "Europe", "Antarctica", "South America"}, 0));
        questions.add(new Question("Which country is home to the Amazon Rainforest?", new String[]{"Brazil", "Colombia", "Peru", "Venezuela"}, 0));
        questions.add(new Question("Which country is known as the 'Land of the Rising Sun'?", new String[]{"Japan", "China", "India", "South Korea"}, 0));
        questions.add(new Question("Which river is known as the 'lifeblood' of India?", new String[]{"Ganges", "Indus", "Brahmaputra", "Yamuna"}, 0));
        questions.add(new Question("Which country is home to the Taj Mahal?", new String[]{"India", "Pakistan", "Bangladesh", "Nepal"}, 0));
        questions.add(new Question("Which continent is the country of Egypt located on?", new String[]{"Africa", "Asia", "Europe", "North America"}, 0));
        questions.add(new Question("Which country is the Eiffel Tower located in?", new String[]{"France", "Italy", "Germany", "Spain"}, 0));
        questions.add(new Question("Which is the world's largest island?", new String[]{"Greenland", "Australia", "New Guinea", "Borneo"}, 0));
        questions.add(new Question("Which continent is the country of Argentina located on?", new String[]{"South America", "North America", "Africa", "Asia"}, 0));
        questions.add(new Question("Which of the following is a landlocked country?", new String[]{"Nepal", "India", "Bangladesh", "Pakistan"}, 0));
        questions.add(new Question("What is the capital of Italy?", new String[]{"Rome", "Milan", "Venice", "Florence"}, 0));
        questions.add(new Question("Which ocean lies to the east of Africa?", new String[]{"Indian Ocean", "Atlantic Ocean", "Pacific Ocean", "Southern Ocean"}, 0));
        questions.add(new Question("What is the highest mountain in Africa?", new String[]{"Mount Kilimanjaro", "Mount Everest", "Mount Fuji", "Mount Elbrus"}, 0));
        questions.add(new Question("Which country is the city of Cairo located in?", new String[]{"Egypt", "Saudi Arabia", "Turkey", "Israel"}, 0));
        questions.add(new Question("What is the capital city of South Korea?", new String[]{"Seoul", "Tokyo", "Beijing", "Hanoi"}, 0));
        questions.add(new Question("Which is the largest desert in the world?", new String[]{"Sahara Desert", "Gobi Desert", "Atacama Desert", "Karakum Desert"}, 0));
        questions.add(new Question("Which country has the longest coastline?", new String[]{"Canada", "Australia", "Russia", "United States"}, 0));
        questions.add(new Question("Which sea is bordered by Italy, Greece, and Turkey?", new String[]{"Aegean Sea", "Mediterranean Sea", "Red Sea", "Black Sea"}, 0));
        questions.add(new Question("What is the capital of Spain?", new String[]{"Madrid", "Barcelona", "Sevilla", "Valencia"}, 0));
        questions.add(new Question("Which mountain range forms the natural border between the United States and Canada?", new String[]{"Rocky Mountains", "Appalachian Mountains", "Sierra Nevada", "Cascade Range"}, 0));
        questions.add(new Question("What is the capital city of Mexico?", new String[]{"Mexico City", "Guadalajara", "Monterrey", "Cancún"}, 0));
        questions.add(new Question("Which country is the island of Iceland a part of?", new String[]{"Iceland", "Greenland", "Denmark", "Norway"}, 0));
        questions.add(new Question("Which desert is located in northern Africa?", new String[]{"Sahara", "Kalahari", "Gobi", "Atacama"}, 0));
        questions.add(new Question("Which river is the longest in Europe?", new String[]{"Volga River", "Danube River", "Rhine River", "Seine River"}, 0));
        questions.add(new Question("Which city is the capital of Egypt?", new String[]{"Cairo", "Alexandria", "Giza", "Luxor"}, 0));
        questions.add(new Question("Which country is known for the Eiffel Tower?", new String[]{"France", "Germany", "Italy", "Spain"}, 0));
        questions.add(new Question("Which continent is the country of Kenya located on?", new String[]{"Africa", "Asia", "Europe", "Australia"}, 0));
        questions.add(new Question("What is the largest continent by area?", new String[]{"Asia", "Africa", "Europe", "North America"}, 0));
        questions.add(new Question("Which country has the most populous city in the world?", new String[]{"Japan", "China", "India", "United States"}, 0));
        questions.add(new Question("Which country is famous for its canals, tulips, and windmills?", new String[]{"Netherlands", "Belgium", "Denmark", "France"}, 0));
        questions.add(new Question("Which country is home to the city of Machu Picchu?", new String[]{"Peru", "Chile", "Brazil", "Bolivia"}, 0));
        questions.add(new Question("What is the capital of Switzerland?", new String[]{"Bern", "Zurich", "Geneva", "Basel"}, 0));
        questions.add(new Question("Which country is the Great Barrier Reef located in?", new String[]{"Australia", "New Zealand", "South Africa", "United States"}, 0));
        questions.add(new Question("Which city is known as the 'Big Apple'?", new String[]{"New York", "Los Angeles", "Chicago", "Boston"}, 0));
        questions.add(new Question("What is the capital city of Argentina?", new String[]{"Buenos Aires", "Santiago", "Lima", "Rio de Janeiro"}, 0));
        questions.add(new Question("Which country is the city of Dubai located in?", new String[]{"United Arab Emirates", "Saudi Arabia", "Qatar", "Oman"}, 0));
        questions.add(new Question("Which continent is the Sahara Desert located on?", new String[]{"Africa", "Asia", "Europe", "North America"}, 0));
        questions.add(new Question("Which continent is the country of Egypt located on?", new String[]{"Africa", "Asia", "Europe", "North America"}, 0));
        questions.add(new Question("Which country has the most pyramids?", new String[]{"Egypt", "Mexico", "Sudan", "China"}, 0));
        questions.add(new Question("Which country is the city of Athens located in?", new String[]{"Greece", "Turkey", "Italy", "France"}, 0));
    }


    // Question class to store question and its answers
    private static class Question {
        private String question;
        private String[] answers;
        private int correctAnswerIndex;

        public Question(String question, String[] answers, int correctAnswerIndex) {
            this.question = question;
            this.answers = answers;
            this.correctAnswerIndex = correctAnswerIndex;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getAnswers() {
            return answers;
        }

        public int getCorrectAnswerIndex() {
            return correctAnswerIndex;
        }

        // Shuffle answers and return the shuffled answers
        public String[] getShuffledAnswers() {
            List<String> answerList = new ArrayList<>();
            Collections.addAll(answerList, answers);
            Collections.shuffle(answerList);

            // Update the correctAnswerIndex after shuffling
            for (int i = 0; i < answerList.size(); i++) {
                if (answerList.get(i).equals(answers[correctAnswerIndex])) {
                    correctAnswerIndex = i;
                    break;
                }
            }

            return answerList.toArray(new String[0]);
        }
    }
}
